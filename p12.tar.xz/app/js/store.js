/* Data layer. Firebase when js/firebase-config.js is filled in, otherwise a local demo
   (this browser only, sample workers) so the app can be tried before setup. */
const EMAIL_DOMAIN = 'workers.jayco.app';           // synthetic login emails: emp0417@workers.jayco.app
const empEmail = (empId) => `emp${String(empId).trim().toLowerCase()}@${EMAIL_DOMAIN}`;
const todayIST = () => new Date(Date.now() + 5.5 * 3600e3).toISOString().slice(0, 10);
const minOfDayIST = (d) => { const t = new Date(d.getTime() + 5.5 * 3600e3); return t.getUTCHours() * 60 + t.getUTCMinutes(); };

function makeFirebaseStore(cfg) {
  firebase.initializeApp(cfg);
  const auth = firebase.auth(), db = firebase.firestore();
  db.enablePersistence({ synchronizeTabs: true }).catch(() => {});
  const TS = () => firebase.firestore.FieldValue.serverTimestamp();
  const toDate = (v) => (v && v.toDate ? v.toDate() : v ? new Date(v) : null);
  const norm = (doc) => { const d = { id: doc.id, ...doc.data() }; d.inAt = toDate(d.inAt); d.outAt = toDate(d.outAt); return d; };
  return {
    mode: 'firebase',
    onAuth: (cb) => auth.onAuthStateChanged(cb),
    // A worker whose PIN was reset by HR approval signs in through a new login; logins/{id} points to it.
    signInWorker: async (empId, pin) => {
      const id = String(empId).trim().toLowerCase();
      let email = empEmail(id);
      try { const l = await db.doc(`logins/${id}`).get({ source: 'server' }); if (l.exists && l.data().email) email = l.data().email; } catch (e) {}
      return auth.signInWithEmailAndPassword(email, pin);
    },
    // Forgot PIN: makes a new login with the new PIN and a request with a selfie. HR checks and approves it.
    requestPinReset: async (mobile, pin, photo) => {
      window.__creatingOwner = true;
      try {
        const email = `emp${mobile}.r${Date.now().toString(36)}@${EMAIL_DOMAIN}`;
        const c = await auth.createUserWithEmailAndPassword(email, pin);
        await db.doc(`pinResets/${c.user.uid}`).set({ mobile, email, photo, requestedAt: TS() });
        await auth.signOut();
      } finally { window.__creatingOwner = false; }
    },
    pinResets: async () => (await db.collection('pinResets').get()).docs.map(d => ({ uid: d.id, ...d.data() })),
    approvePinReset: async (req, old) => {
      const { uid: oldUid, ...data } = old;
      const b = db.batch();
      b.set(db.doc(`workers/${req.uid}`), { ...data, active: true, status: 'approved', pinResetAt: TS() });
      b.set(db.doc(`workers/${oldUid}`), { active: false, status: 'replaced', replacedBy: req.uid }, { merge: true });
      new Set([String(old.phone || ''), String(old.empId || ''), String(req.mobile)].map(x => x.trim().toLowerCase()).filter(Boolean))
        .forEach(id => b.set(db.doc(`logins/${id}`), { email: req.email, uid: req.uid, at: TS() }));
      b.delete(db.doc(`pinResets/${req.uid}`));
      await b.commit();
    },
    rejectPinReset: (uid) => db.doc(`pinResets/${uid}`).delete(),
    registerSelf: async (w, pin) => {
      // Worker creates their own login (mobile number as ID) and a profile that stays inactive until HR approves.
      window.__creatingOwner = true;
      try {
        const c = await auth.createUserWithEmailAndPassword(empEmail(w.mobile), pin);
        await db.doc(`workers/${c.user.uid}`).set({ empId: w.mobile, name: w.name, phone: w.mobile, dept: w.dept, photo: w.photo, shift: w.shift, rulesAccepted: true,
          role: 'worker', active: false, status: 'pending', dailyWage: 0, registeredAt: TS() });
      } finally { window.__creatingOwner = false; }
      location.reload();
    },
    signInAdmin: (email, pw) => auth.signInWithEmailAndPassword(email, pw),
    resetPassword: (email) => auth.sendPasswordResetEmail(email),
    createOwner: async (email, pw, name) => {
      window.__creatingOwner = true;          // stop the sign-in listener until the profile exists
      try {
        const c = await auth.createUserWithEmailAndPassword(email, pw);
        await db.doc(`workers/${c.user.uid}`).set({ empId: 'ADMIN', name, role: 'admin', active: true, dailyWage: 0, email });
      } finally { window.__creatingOwner = false; }
      location.reload();
    },
    signOut: () => auth.signOut(),
    changePin: (pin) => auth.currentUser.updatePassword(pin),
    me: async () => { const u = auth.currentUser; if (!u) return null; const s = await db.doc(`workers/${u.uid}`).get(); return s.exists ? { uid: u.uid, ...s.data() } : null; },
    getSettings: async () => { const s = await db.doc('settings/main').get(); return { ...RULES.DEFAULTS, ...(s.exists ? s.data() : {}) }; },
    saveSettings: (s) => db.doc('settings/main').set(s, { merge: true }),
    listWorkers: async () => (await db.collection('workers').get()).docs.map(d => ({ uid: d.id, ...d.data() })).filter(w => w.status !== 'replaced'),
    saveWorker: (uid, data) => db.doc(`workers/${uid}`).set(data, { merge: true }),
    createWorker: async (w, pin) => {
      // A second app instance creates the login without signing HR out.
      const sec = firebase.apps.find(a => a.name === 'sec') || firebase.initializeApp(cfg, 'sec');
      const c = await sec.auth().createUserWithEmailAndPassword(empEmail(w.empId), pin);
      await sec.auth().signOut();
      await db.doc(`workers/${c.user.uid}`).set({ ...w, active: true });
      return c.user.uid;
    },
    getDay: async (empId, date) => { const s = await db.doc(`attendance/${empId}_${date}`).get(); return s.exists ? norm(s) : null; },
    checkIn: async (rec, selfie) => {
      const id = `${rec.empId}_${rec.date}`;
      await db.doc(`attendance/${id}`).set({ ...rec, inAt: TS(), outAt: null });
      await db.doc(`selfies/${id}`).set({ empId: rec.empId, date: rec.date, in: selfie });
    },
    saveWork: (empId, date, work) => db.doc(`attendance/${empId}_${date}`).update({ work, workStatus: 'pending' }),
    checkOut: async (empId, date, rec, selfie) => {
      await db.doc(`attendance/${empId}_${date}`).update({ ...rec, outAt: TS() });
      await db.doc(`selfies/${empId}_${date}`).set({ out: selfie }, { merge: true });
    },
    getSelfies: async (id) => { const s = await db.doc(`selfies/${id}`).get(); return s.exists ? s.data() : {}; },
    purgeSelfies: async (beforeDate) => {
      const q = await db.collection('selfies').where('date', '<', beforeDate).limit(400).get();
      const b = db.batch(); q.docs.forEach(d => b.delete(d.ref)); await b.commit(); return q.size;
    },
    setWorkStatus: (id, status, by) => db.doc(`attendance/${id}`).update({ workStatus: status, reviewedBy: by }),
    editTimes: (id, patch) => db.doc(`attendance/${id}`).update(patch),
    dayList: async (date) => (await db.collection('attendance').where('date', '==', date).get()).docs.map(norm),
    monthList: async (month, empId) => {
      let q = db.collection('attendance').where('month', '==', month);
      if (empId) q = q.where('empId', '==', empId);
      return (await q.get()).docs.map(norm);
    },
    advances: async (month, empId) => {
      let q = db.collection('advances').where('month', '==', month);
      if (empId) q = q.where('empId', '==', empId);
      return (await q.get()).docs.map(d => ({ id: d.id, ...d.data() }));
    },
    // Phone reminders: the device token is kept per login so the reminder sender can reach this phone.
    enablePush: async (extra) => {
      if (!firebase.messaging) await new Promise((ok, no) => { const sc = document.createElement('script'); sc.src = 'https://www.gstatic.com/firebasejs/10.12.2/firebase-messaging-compat.js'; sc.onload = ok; sc.onerror = no; document.head.appendChild(sc); });
      if (!(await firebase.messaging.isSupported())) throw new Error('unsupported');
      const reg = await navigator.serviceWorker.ready;
      const token = await firebase.messaging().getToken({ serviceWorkerRegistration: reg });
      if (!token) throw new Error('no token');
      await db.doc(`pushTokens/${auth.currentUser.uid}`).set({ token, ...extra, updatedAt: TS() }, { merge: true });
      return token;
    },
    setPushInfo: (extra) => db.doc(`pushTokens/${auth.currentUser.uid}`).set({ ...extra, updatedAt: TS() }, { merge: true }).catch(() => {}),
    addAdvance: (a) => db.collection('advances').add({ ...a, at: TS() }),
    deleteAdvance: (id) => db.doc(`advances/${id}`).delete(),
    loans: async (empId) => {
      let q = db.collection('loans');
      if (empId) q = q.where('empId', '==', empId);
      return (await q.get()).docs.map(d => ({ id: d.id, ...d.data() }));
    },
    addLoan: (l) => db.collection('loans').add({ ...l, at: TS() }),
    settleLoan: (id, month) => db.doc(`loans/${id}`).update({ settledMonth: month }),
    deleteLoan: (id) => db.doc(`loans/${id}`).delete()
  };
}

function makeDemoStore() {
  const K = 'jayco-demo-v1';
  let st;
  try { st = JSON.parse(localStorage.getItem(K)); } catch (e) { st = null; }
  const save = () => { try { localStorage.setItem(K, JSON.stringify(st)); } catch (e) {} };
  if (!st) {
    const names = [['0417', 'Ramesh Thakor', 'Machine shop', 650], ['0418', 'Kiran Patel', 'Machine shop', 600], ['0421', 'Mahesh Vaghela', 'Painting', 550],
      ['0425', 'Sunil Parmar', 'Foundry', 600], ['0430', 'Jignesh Solanki', 'Assembly', 575], ['0433', 'Prakash Rathod', 'Machine shop', 700]];
    st = { settings: {}, workers: {}, att: {}, adv: [], pins: {}, user: null };
    st.workers.admin = { empId: 'ADMIN', name: 'HR (demo)', role: 'admin', active: true, dailyWage: 0, email: 'hr@demo' };
    st.pins['hr@demo'] = { uid: 'admin', pw: 'demo123' };
    names.forEach(([id, n, dept, wage], i) => {
      const uid = 'w' + id; st.workers[uid] = { empId: id, name: n, dept, dailyWage: wage, role: i === 5 ? 'supervisor' : 'worker', active: true, phone: '' };
      st.pins[empEmail(id)] = { uid, pw: '111111' };
    });
    // Sample history for this month so payroll shows numbers
    const now = new Date(Date.now() + 5.5 * 3600e3); const y = now.getUTCFullYear(), m = now.getUTCMonth();
    for (let d = 1; d < now.getUTCDate(); d++) {
      const date = `${y}-${String(m + 1).padStart(2, '0')}-${String(d).padStart(2, '0')}`;
      if (new Date(date + 'T00:00:00').getDay() === 0) continue;
      names.forEach(([id], i) => {
        if ((d + i) % 11 === 0) return;
        const shift = (i % 3) + 1, sh = RULES.DEFAULTS.shifts[shift];
        const inM = RULES.toMin(sh.start) - 5 + ((d * 7 + i * 3) % 14), outM = RULES.toMin(sh.end) + ((d + i) % 4) * 45;
        const mk = (mm) => new Date(`${date}T${String(Math.floor(mm / 60)).padStart(2, '0')}:${String(mm % 60).padStart(2, '0')}:00+05:30`).toISOString();
        st.att[`${id}_${date}`] = { empId: id, date, month: date.slice(0, 7), shift, inAt: mk(inM), outAt: mk(outM), inDist: 12 + i * 5, outDist: 20,
          work: { part: PARTS[i % 7], op: ['CNC boring', 'Turning', 'Painting', 'Casting', 'Assembly', 'Inspection'][i], qty: 20 + i * 10, machine: 'M-' + (i + 1), notes: '' }, workStatus: 'approved', demo: true };
      });
    }
    save();
  }
  const selfies = {};   // demo keeps selfies in memory only, to stay within browser storage
  const D = (v) => (v ? new Date(v) : null);
  const norm = (id, r) => ({ id, ...r, inAt: D(r.inAt), outAt: D(r.outAt) });
  let listener = null;
  const fire = () => listener && listener(st.user ? { uid: st.user } : null);
  return {
    mode: 'demo',
    onAuth: (cb) => { listener = cb; setTimeout(fire, 0); },
    registerSelf: async (w, pin) => { if (st.pins[empEmail(w.mobile)]) { const e = new Error('used'); e.code = 'auth/email-already-in-use'; throw e; }
      const uid = 'r' + w.mobile; st.workers[uid] = { empId: w.mobile, name: w.name, phone: w.mobile, dept: w.dept, photo: w.photo, shift: w.shift, rulesAccepted: true, role: 'worker', active: false, status: 'pending', dailyWage: 0 };
      st.pins[empEmail(w.mobile)] = { uid, pw: pin }; st.user = uid; save(); fire(); },
    signInWorker: async (empId, pin) => { const p = st.pins[empEmail(empId)]; if (!p || p.pw !== pin) throw new Error('Wrong employee ID or PIN'); st.user = p.uid; save(); fire(); },
    signInAdmin: async (email, pw) => { const p = st.pins[email]; if (!p || p.pw !== pw) throw new Error('Wrong email or password'); st.user = p.uid; save(); fire(); },
    createOwner: async () => { throw new Error('Not available in demo'); },
    resetPassword: async () => { throw new Error('Not available in demo'); },
    requestPinReset: async () => { throw new Error('Not available in demo'); },
    pinResets: async () => [], approvePinReset: async () => {}, rejectPinReset: async () => {},
    signOut: async () => { st.user = null; save(); fire(); },
    changePin: async (pin) => { const e = Object.keys(st.pins).find(k => st.pins[k].uid === st.user); st.pins[e].pw = pin; save(); },
    me: async () => (st.user ? { uid: st.user, ...st.workers[st.user] } : null),
    getSettings: async () => ({ ...RULES.DEFAULTS, ...st.settings }),
    saveSettings: async (s) => { st.settings = { ...st.settings, ...s }; save(); },
    listWorkers: async () => Object.entries(st.workers).map(([uid, w]) => ({ uid, ...w })),
    saveWorker: async (uid, data) => { st.workers[uid] = { ...st.workers[uid], ...data }; save(); },
    createWorker: async (w, pin) => { const uid = 'w' + w.empId; if (st.workers[uid]) throw new Error('Employee ID already exists'); st.workers[uid] = { ...w, active: true }; st.pins[empEmail(w.empId)] = { uid, pw: pin }; save(); return uid; },
    getDay: async (empId, date) => { const r = st.att[`${empId}_${date}`]; return r ? norm(`${empId}_${date}`, r) : null; },
    checkIn: async (rec, selfie) => { const id = `${rec.empId}_${rec.date}`; st.att[id] = { ...rec, inAt: new Date().toISOString(), outAt: null }; selfies[id] = { in: selfie }; save(); },
    saveWork: async (empId, date, work) => { Object.assign(st.att[`${empId}_${date}`], { work, workStatus: 'pending' }); save(); },
    checkOut: async (empId, date, rec, selfie) => { const id = `${empId}_${date}`; Object.assign(st.att[id], { ...rec, outAt: new Date().toISOString() }); selfies[id] = { ...(selfies[id] || {}), out: selfie }; save(); },
    getSelfies: async (id) => selfies[id] || {},
    purgeSelfies: async () => 0,
    setWorkStatus: async (id, status, by) => { Object.assign(st.att[id], { workStatus: status, reviewedBy: by }); save(); },
    editTimes: async (id, patch) => { const p = { ...patch }; ['inAt', 'outAt'].forEach(k => { if (p[k] instanceof Date) p[k] = p[k].toISOString(); }); Object.assign(st.att[id], p); save(); },
    dayList: async (date) => Object.entries(st.att).filter(([, r]) => r.date === date).map(([id, r]) => norm(id, r)),
    monthList: async (month, empId) => Object.entries(st.att).filter(([, r]) => r.month === month && (!empId || r.empId === empId)).map(([id, r]) => norm(id, r)),
    advances: async (month, empId) => st.adv.filter(a => a.month === month && (!empId || a.empId === empId)),
    enablePush: async () => { if (!('Notification' in window)) throw new Error('unsupported'); const p = await Notification.requestPermission(); if (p !== 'granted') throw new Error('blocked'); return 'demo'; },
    setPushInfo: async () => {},
    addAdvance: async (a) => { st.adv.push({ ...a, id: 'a' + Date.now() }); save(); },
    deleteAdvance: async (id) => { st.adv = st.adv.filter(a => a.id !== id); save(); },
    loans: async (empId) => (st.loans || []).filter(l => !empId || l.empId === empId),
    addLoan: async (l) => { (st.loans = st.loans || []).push({ ...l, id: 'l' + Date.now() }); save(); },
    settleLoan: async (id, month) => { const l = (st.loans || []).find(x => x.id === id); if (l) l.settledMonth = month; save(); },
    deleteLoan: async (id) => { st.loans = (st.loans || []).filter(l => l.id !== id); save(); },
    resetDemo: () => { try { localStorage.removeItem(K); } catch (e) {} location.reload(); }
  };
}
