#!/usr/bin/env python3
"""Deploy app/ to Firebase Hosting with the REST API, using the signed-in gcloud account.
Run in Google Cloud Shell:  python3 deploy.py"""
import gzip, hashlib, json, os, subprocess, urllib.request

PROJECT = SITE = 'jayco-attendance-ea440'
API = 'https://firebasehosting.googleapis.com/v1beta1'
TOKEN = subprocess.check_output(['gcloud', 'auth', 'print-access-token'], text=True).strip()

def call(method, url, body=None, raw=None, ctype='application/json'):
    data = raw if raw is not None else (json.dumps(body).encode() if body is not None else None)
    req = urllib.request.Request(url, data=data, method=method, headers={
        'Authorization': 'Bearer ' + TOKEN, 'Content-Type': ctype, 'x-goog-user-project': PROJECT})
    try:
        with urllib.request.urlopen(req) as r:
            txt = r.read().decode()
            return json.loads(txt) if txt.strip() else {}
    except urllib.error.HTTPError as e:
        raise SystemExit(f'{method} {url} failed: {e.code} {e.read().decode()[:600]}')

files = {}
for root, _, names in os.walk('app'):
    for n in names:
        p = os.path.join(root, n)
        if '/test' in p or n.startswith('.'):
            continue
        gz = gzip.compress(open(p, 'rb').read(), mtime=0)
        files['/' + os.path.relpath(p, 'app')] = (hashlib.sha256(gz).hexdigest(), gz)

cfg = json.load(open('firebase.json'))['hosting']
headers = [{'glob': '**', 'headers': {'Cache-Control': 'no-cache', 'Permissions-Policy': 'camera=(self), geolocation=(self)'}},
           {'glob': '**/*.png', 'headers': {'Cache-Control': 'max-age=86400'}}]
v = call('POST', f'{API}/sites/{SITE}/versions', {'config': {'headers': headers}})
name = v['name']
print('Version', name)
pop = call('POST', f'{API}/{name}:populateFiles', {'files': {k: h for k, (h, _) in files.items()}})
need = set(pop.get('uploadRequiredHashes', []))
for path, (h, gz) in files.items():
    if h in need:
        call('POST', f"{pop['uploadUrl']}/{h}", raw=gz, ctype='application/octet-stream')
        print('uploaded', path)
call('PATCH', f'{API}/{name}?update_mask=status', {'status': 'FINALIZED'})
call('POST', f'{API}/sites/{SITE}/releases?versionName={name}', {})
print(f'\nDEPLOYED: https://{SITE}.web.app')
