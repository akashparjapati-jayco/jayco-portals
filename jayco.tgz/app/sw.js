// Caches the app shell so it opens fast on weak factory networks. Data always comes from Firebase.
const CACHE = 'jayco-v16';
const SHELL = ['./', 'index.html', 'css/app.css', 'js/rules.js', 'js/i18n.js', 'js/store.js', 'js/app.js', 'js/hr.js', 'js/firebase-config.js', 'js/ios.js', 'icons/apple-touch-icon.png', 'icons/logo-white.png', 'icons/icon-192.png'];
self.addEventListener('install', e => e.waitUntil(caches.open(CACHE).then(c => c.addAll(SHELL)).then(() => self.skipWaiting())));
self.addEventListener('activate', e => e.waitUntil(caches.keys().then(ks => Promise.all(ks.filter(k => k !== CACHE).map(k => caches.delete(k)))).then(() => self.clients.claim())));
self.addEventListener('fetch', e => {
  const u = new URL(e.request.url);
  if (e.request.method !== 'GET' || u.origin !== location.origin) return;
  // Network first, cache as fallback, so updates reach workers right away.
  e.respondWith(fetch(e.request).then(r => { const c = r.clone(); caches.open(CACHE).then(x => x.put(e.request, c)); return r; }).catch(() => caches.match(e.request)));
});

// Reminders sent by the JAYCO reminder sender through Firebase Cloud Messaging.
self.addEventListener('push', e => {
  let d = {}; try { d = e.data ? e.data.json() : {}; } catch (x) {}
  const n = d.notification || d.data || {};
  e.waitUntil(self.registration.showNotification(n.title || 'JAYCO', {
    body: n.body || '', icon: 'icons/icon-192.png', badge: 'icons/icon-192.png', tag: (d.data && d.data.tag) || 'jayco', renotify: true,
    data: { link: (d.data && d.data.link) || './' }
  }));
});
self.addEventListener('notificationclick', e => {
  e.notification.close();
  e.waitUntil(self.clients.matchAll({ type: 'window', includeUncontrolled: true }).then(cs => {
    const c = cs.find(x => x.url.startsWith(self.registration.scope)); return c ? c.focus() : self.clients.openWindow('./');
  }));
});
