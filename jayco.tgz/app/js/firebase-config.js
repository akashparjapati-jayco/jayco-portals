// Firebase web app config for JAYCO Attendance (public identifiers, safe to ship in the app).
// Access to data is controlled by firestore.rules.
window.FIREBASE_CONFIG = {
  apiKey: 'AIzaSyCLwyn8ckPiPduiiyn8xEpd-IMrc9r8NN8',
  authDomain: 'jayco-attendance-ea440.firebaseapp.com',
  projectId: 'jayco-attendance-ea440',
  storageBucket: 'jayco-attendance-ea440.firebasestorage.app',
  messagingSenderId: '128875283699',
  appId: '1:128875283699:web:e009383055dede5e36a386'
};
