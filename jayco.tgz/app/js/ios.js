/* JAYCO Attendance: iPhone / iPad support.
   - Detects iPhone Safari and shows a one-time "Add to Home Screen" guide (Gujarati / Hindi / English).
   - iPhone-specific help for blocked location, camera and reminders.
   Loaded before app.js; app.js calls these helpers only when IS_IOS is true. */
const IS_IOS = /iPhone|iPad|iPod/i.test(navigator.userAgent) || (navigator.platform === 'MacIntel' && navigator.maxTouchPoints > 1);
const IS_STANDALONE = !!(window.navigator.standalone || (window.matchMedia && window.matchMedia('(display-mode: standalone)').matches));
const IOS_BROWSER = /CriOS/i.test(navigator.userAgent) ? 'chrome' : /FxiOS|EdgiOS/i.test(navigator.userAgent) ? 'other'
  : /FBAN|FBAV|Instagram|Line\/|WhatsApp/i.test(navigator.userAgent) ? 'inapp' : 'safari';
if (IS_IOS) document.documentElement.classList.add('ios');
if (IS_STANDALONE) document.documentElement.classList.add('standalone');

const IOS_T = {
  en: {
    title: 'Install JAYCO on your iPhone',
    intro: 'Add JAYCO to your Home Screen. It opens like an app, full screen, and can send you reminders.',
    s1safari: 'Tap the Share button {share} in Safari. On new iPhones (iOS 26), tap ••• at the bottom first, then Share.',
    s1chrome: 'Tap the Share button {share} at the top right, next to the address bar.',
    s2: 'Scroll down and tap "Add to Home Screen" {add}.',
    s3: 'Tap "Add" at the top right. Then open JAYCO from your Home Screen and sign in once.',
    inapp: 'You opened this link inside another app. Tap ••• or the compass button and choose "Open in Safari", then follow these steps.',
    later: 'Later', got: 'Done, I added it',
    small: 'Install JAYCO app', smallNote: 'Add to Home Screen for full screen and reminders.', how: 'Show me how',
    remIos: 'On iPhone, reminders work only when JAYCO is added to the Home Screen (iOS 16.4 or newer).',
    locSteps: [
      'Open iPhone Settings > Privacy & Security > Location Services and turn it ON.',
      'On the same screen scroll down to "Safari Websites" and choose "While Using the App". Turn ON "Precise Location".',
      'Open Settings > Apps > Safari > Location (older iPhones: Settings > Safari > Location) and choose "Allow".',
      'Come back to JAYCO and tap "Try again". If iPhone asks, tap "Allow".'
    ],
    camSteps: 'Camera is blocked. Open Settings > Apps > Safari > Camera and choose "Allow", then try again.'
  },
  gu: {
    title: 'iPhone પર JAYCO ઇન્સ્ટોલ કરો',
    intro: 'JAYCO ને Home Screen પર ઉમેરો. તે એપની જેમ પૂરી સ્ક્રીન પર ખુલશે અને રિમાઇન્ડર પણ આવશે.',
    s1safari: 'Safari માં Share બટન {share} દબાવો. નવા iPhone (iOS 26) માં પહેલાં નીચે ••• દબાવો, પછી Share.',
    s1chrome: 'ઉપર જમણી બાજુ, એડ્રેસ બાર પાસે Share બટન {share} દબાવો.',
    s2: 'નીચે સ્ક્રોલ કરો અને "Add to Home Screen" {add} દબાવો.',
    s3: 'ઉપર જમણી બાજુ "Add" દબાવો. પછી Home Screen પરથી JAYCO ખોલો અને એક વાર સાઇન ઇન કરો.',
    inapp: 'આ લિંક બીજી એપની અંદર ખુલી છે. ••• અથવા કંપાસ બટન દબાવો, "Open in Safari" પસંદ કરો, પછી આ સ્ટેપ કરો.',
    later: 'પછી', got: 'થઈ ગયું, ઉમેરી દીધું',
    small: 'JAYCO એપ ઇન્સ્ટોલ કરો', smallNote: 'પૂરી સ્ક્રીન અને રિમાઇન્ડર માટે Home Screen પર ઉમેરો.', how: 'કેવી રીતે તે બતાવો',
    remIos: 'iPhone પર રિમાઇન્ડર ત્યારે જ આવે જ્યારે JAYCO Home Screen પર ઉમેરેલું હોય (iOS 16.4 કે નવું).',
    locSteps: [
      'iPhone Settings > Privacy & Security > Location Services ખોલો અને ચાલુ (ON) કરો.',
      'એ જ સ્ક્રીનમાં નીચે "Safari Websites" માં "While Using the App" પસંદ કરો. "Precise Location" ચાલુ કરો.',
      'Settings > Apps > Safari > Location ખોલો (જૂના iPhone: Settings > Safari > Location) અને "Allow" પસંદ કરો.',
      'JAYCO માં પાછા આવો અને "ફરી પ્રયાસ કરો" દબાવો. iPhone પૂછે તો "Allow" દબાવો.'
    ],
    camSteps: 'કૅમેરા બંધ છે. Settings > Apps > Safari > Camera માં "Allow" પસંદ કરો, પછી ફરી પ્રયાસ કરો.'
  },
  hi: {
    title: 'iPhone पर JAYCO इंस्टॉल करें',
    intro: 'JAYCO को Home Screen पर जोड़ें. यह ऐप की तरह पूरी स्क्रीन पर खुलेगा और रिमाइंडर भी आएंगे.',
    s1safari: 'Safari में Share बटन {share} दबाएं. नए iPhone (iOS 26) में पहले नीचे ••• दबाएं, फिर Share.',
    s1chrome: 'ऊपर दाईं ओर, एड्रेस बार के पास Share बटन {share} दबाएं.',
    s2: 'नीचे स्क्रॉल करें और "Add to Home Screen" {add} दबाएं.',
    s3: 'ऊपर दाईं ओर "Add" दबाएं. फिर Home Screen से JAYCO खोलें और एक बार साइन इन करें.',
    inapp: 'यह लिंक किसी दूसरे ऐप के अंदर खुला है. ••• या कंपास बटन दबाएं, "Open in Safari" चुनें, फिर ये स्टेप करें.',
    later: 'बाद में', got: 'हो गया, जोड़ दिया',
    small: 'JAYCO ऐप इंस्टॉल करें', smallNote: 'पूरी स्क्रीन और रिमाइंडर के लिए Home Screen पर जोड़ें.', how: 'कैसे करें, दिखाएं',
    remIos: 'iPhone पर रिमाइंडर तभी आते हैं जब JAYCO Home Screen पर जोड़ा हो (iOS 16.4 या नया).',
    locSteps: [
      'iPhone Settings > Privacy & Security > Location Services खोलें और चालू (ON) करें.',
      'उसी स्क्रीन में नीचे "Safari Websites" में "While Using the App" चुनें. "Precise Location" चालू करें.',
      'Settings > Apps > Safari > Location खोलें (पुराने iPhone: Settings > Safari > Location) और "Allow" चुनें.',
      'JAYCO में वापस आएं और "फिर कोशिश करें" दबाएं. iPhone पूछे तो "Allow" दबाएं.'
    ],
    camSteps: 'कैमरा बंद है. Settings > Apps > Safari > Camera में "Allow" चुनें, फिर दोबारा कोशिश करें.'
  }
};
const iosT = (k) => { const L = (typeof LANG !== 'undefined' && IOS_T[LANG]) ? LANG : 'en'; return IOS_T[L][k] ?? IOS_T.en[k]; };
const IOS_SHARE_SVG = '<svg class="ios-glyph" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" aria-label="Share"><path d="M12 3v12"/><path d="M8 7l4-4 4 4"/><path d="M6 11H5a1 1 0 0 0-1 1v8a1 1 0 0 0 1 1h14a1 1 0 0 0 1-1v-8a1 1 0 0 0-1-1h-1"/></svg>';
const IOS_ADD_SVG = '<svg class="ios-glyph" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" aria-label="Add"><rect x="3.5" y="3.5" width="17" height="17" rx="4"/><path d="M12 8v8M8 12h8"/></svg>';
const iosFill = (s) => String(s).replace(/[&<>"]/g, c => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;' }[c]))
  .replace('{share}', IOS_SHARE_SVG).replace('{add}', IOS_ADD_SVG);

/* Should we offer the Home Screen install? Only on iPhone/iPad, in the browser (not already installed). */
const iosNeedsInstall = () => IS_IOS && !IS_STANDALONE;

/* Full guide as a bottom sheet. force = opened by the worker; otherwise shown once per browser session. */
function iosInstallGuide(force) {
  if (!iosNeedsInstall()) return;
  try { if (!force && sessionStorage.getItem('jayco-ios-guide')) return; sessionStorage.setItem('jayco-ios-guide', '1'); } catch (e) { if (!force) return; }
  if (document.querySelector('.ios-guide')) return;
  const m = document.createElement('div'); m.className = 'modal tour-modal ios-guide'; m.setAttribute('role', 'dialog'); m.setAttribute('aria-modal', 'true');
  const s1 = IOS_BROWSER === 'chrome' ? 's1chrome' : 's1safari';
  m.innerHTML = `<div class="sheet tour ios-sheet">
      <img src="icons/apple-touch-icon.png" alt="" class="ios-appicon" width="76" height="76">
      <h2>${iosFill(iosT('title'))}</h2><p>${iosFill(iosT('intro'))}</p>
      ${IOS_BROWSER === 'inapp' ? `<p class="err">${iosFill(iosT('inapp'))}</p>` : ''}
      <ol class="ios-steps">
        <li><b>1</b><span>${iosFill(iosT(s1))}</span></li>
        <li><b>2</b><span>${iosFill(iosT('s2'))}</span></li>
        <li><b>3</b><span>${iosFill(iosT('s3'))}</span></li>
      </ol>
      <button class="btn" id="ios-ok">${iosFill(iosT('got'))}</button>
      <button class="link" id="ios-later">${iosFill(iosT('later'))}</button>
    </div>`;
  const close = () => m.remove();
  m.querySelector('#ios-ok').onclick = close; m.querySelector('#ios-later').onclick = close;
  m.addEventListener('click', (e) => { if (e.target === m) close(); });
  document.body.appendChild(m);
}

/* Small card for the sign-in and home screens. */
function iosInstallCard(note) {
  if (!iosNeedsInstall()) return '';
  return `<div class="card ios-card"><img src="icons/apple-touch-icon.png" alt="" width="48" height="48">
    <div class="grow"><b>${iosFill(iosT('small'))}</b><div class="note">${iosFill(note || iosT('smallNote'))}</div>
    <button class="link" data-ios-guide>${iosFill(iosT('how'))}</button></div></div>`;
}
document.addEventListener('click', (e) => { const b = e.target.closest && e.target.closest('[data-ios-guide]'); if (b) { e.preventDefault(); iosInstallGuide(true); } });
