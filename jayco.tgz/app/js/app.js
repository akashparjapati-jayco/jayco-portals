/* JAYCO Attendance: worker app (default) and HR panel (#hr). */
const $ = (sel, el = document) => el.querySelector(sel);
const esc = (v) => String(v ?? '').replace(/[&<>"']/g, c => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]));
const inr = (n) => '₹' + Math.round(n || 0).toLocaleString('en-IN');
const hhmm = (d) => d ? new Date(d.getTime() + 5.5 * 3600e3).toISOString().slice(11, 16) : '—';
const monthIST = () => todayIST().slice(0, 7);
const app = $('#app');
let store, S, ME, LANG;
try { LANG = localStorage.getItem('jayco-lang') || 'en'; } catch (e) { LANG = 'en'; }
const t = (k) => (I18N[LANG] && I18N[LANG][k]) || I18N.en[k] || k;
document.documentElement.lang = LANG;

function toast(msg, kind = '') {
  const el = document.createElement('div'); el.className = 'toast ' + kind; el.textContent = msg;
  document.body.appendChild(el); setTimeout(() => el.remove(), 3500);
}
function busy(btn, on) { if (!btn) return; btn.disabled = on; if (on) { btn.dataset.l = btn.textContent; btn.textContent = t('saving'); } else if (btn.dataset.l) btn.textContent = btn.dataset.l; }
function logoBar(right = '') {
  return `<header class="bar"><img src="icons/logo-white.png" alt="JAYCO" class="bar-logo"><div class="bar-right">${right}</div></header>`;
}
function demoBanner() { return store.mode === 'demo' ? `<div class="demo">Demo mode: sample data on this device only. <button class="link" id="reset-demo">Reset demo</button></div>` : ''; }
function wireDemo() { const b = $('#reset-demo'); if (b) b.onclick = () => store.resetDemo(); }

/* ---------- Icons (inline SVG, sharp at any screen resolution) ---------- */
const ICONS = {
  home: '<path d="M3 10.5 12 3l9 7.5"/><path d="M5 9.5V20h5v-6h4v6h5V9.5"/>',
  wallet: '<rect x="3" y="6" width="18" height="14" rx="3"/><path d="M3 10h18"/><circle cx="16.5" cy="15" r="1.3"/><path d="M7 6V5a2 2 0 0 1 2-2h8"/>',
  book: '<path d="M4 4.5A2.5 2.5 0 0 1 6.5 2H20v17H6.5A2.5 2.5 0 0 0 4 21.5z"/><path d="M4 21.5V4.5"/><path d="M8 7h8M8 11h6"/>',
  help: '<circle cx="12" cy="12" r="9"/><path d="M9.5 9.5a2.5 2.5 0 1 1 3.5 2.3c-.7.3-1 .9-1 1.7"/><circle cx="12" cy="17" r=".6" fill="currentColor"/>',
  clock: '<circle cx="12" cy="12" r="9"/><path d="M12 7v5l3 2"/>',
  pin: '<path d="M12 21s-7-6.2-7-11.5A7 7 0 0 1 19 9.5C19 14.8 12 21 12 21z"/><circle cx="12" cy="9.5" r="2.5"/>',
  camera: '<path d="M4 8h3l2-3h6l2 3h3a1 1 0 0 1 1 1v10a1 1 0 0 1-1 1H4a1 1 0 0 1-1-1V9a1 1 0 0 1 1-1z"/><circle cx="12" cy="13.5" r="3.5"/>',
  clipboard: '<rect x="5" y="4" width="14" height="17" rx="2"/><path d="M9 4V3h6v1"/><path d="M8.5 10h7M8.5 14h7M8.5 18h4"/>',
  logout: '<path d="M15 4h3a2 2 0 0 1 2 2v12a2 2 0 0 1-2 2h-3"/><path d="M10 16l-4-4 4-4"/><path d="M6 12h10"/>',
  login: '<path d="M9 4H6a2 2 0 0 0-2 2v12a2 2 0 0 0 2 2h3"/><path d="M14 16l4-4-4-4"/><path d="M18 12H8"/>',
  bell: '<path d="M6 16V11a6 6 0 1 1 12 0v5l1.5 2h-15z"/><path d="M10 20a2 2 0 0 0 4 0"/>',
  check: '<path d="M5 12.5l4.5 4.5L19 7.5"/>',
  shift: '<circle cx="12" cy="12" r="4"/><path d="M12 2v2M12 20v2M4.9 4.9l1.4 1.4M17.7 17.7l1.4 1.4M2 12h2M20 12h2M4.9 19.1l1.4-1.4M17.7 6.3l1.4-1.4"/>',
  rupee: '<path d="M7 4h10M7 8.5h10M7 4c5 0 6.5 1.7 6.5 4.5S11 13 7 13l7 7"/>',
  shield: '<path d="M12 3l8 3v6c0 4.5-3.4 8-8 9-4.6-1-8-4.5-8-9V6z"/><path d="M8.5 12l2.5 2.5 4.5-5"/>',
  calendar: '<rect x="3" y="5" width="18" height="16" rx="2"/><path d="M3 10h18M8 3v4M16 3v4"/>',
  hourglass: '<path d="M7 3h10M7 21h10M8 3c0 5 8 5 8 9s-8 4-8 9M16 3c0 5-8 5-8 9s8 4 8 9"/>',
  user: '<circle cx="12" cy="8" r="4"/><path d="M4 21c1.5-4 4.5-6 8-6s6.5 2 8 6"/>',
  bearing: '<circle cx="12" cy="12" r="9"/><circle cx="12" cy="12" r="4"/><circle cx="12" cy="5.5" r="1.2"/><circle cx="18.5" cy="12" r="1.2"/><circle cx="12" cy="18.5" r="1.2"/><circle cx="5.5" cy="12" r="1.2"/><circle cx="16.6" cy="7.4" r="1.2"/><circle cx="16.6" cy="16.6" r="1.2"/><circle cx="7.4" cy="16.6" r="1.2"/><circle cx="7.4" cy="7.4" r="1.2"/>'
};
const ic = (n, cls = '') => `<svg class="ic ${cls}" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.9" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true">${ICONS[n] || ''}</svg>`;
const shiftLabel = (n) => `${t('shift')} ${n} · ${S.shifts[n].start}–${S.shifts[n].end}`;
const myShift = () => [1, 2, 3].includes(Number(ME && ME.shift)) ? Number(ME.shift) : 0;

function tabbar(active) {
  const tabs = [['home', 'home', 'tabHome'], ['pay', 'wallet', 'tabPay'], ['rules', 'book', 'tabRules'], ['help', 'help', 'tabHelp']];
  return `<nav class="tabbar" aria-label="Menu">${tabs.map(([k, i, l]) => `<button data-tab="${k}" ${k === active ? 'aria-current="page"' : ''}>${ic(i)}<span>${t(l)}</span></button>`).join('')}</nav>`;
}
function wireTabbar() {
  app.querySelectorAll('.tabbar [data-tab]').forEach(b => b.onclick = () => {
    const k = b.dataset.tab;
    if (k === 'home') workerHome(); else if (k === 'pay') payScreen(monthIST()); else if (k === 'rules') rulesScreen(); else showTour(true);
  });
}
function workerFrame(active) {
  document.body.classList.add('wk');
  app.innerHTML = `${logoBar(`<span class="mono">${hhmm(new Date())}</span><button class="iconbtn" id="signout" aria-label="${t('signout')}" title="${t('signout')}">${ic('logout')}</button>`)}${demoBanner()}<main class="pad stack wkmain" id="main"></main>${tabbar(active)}`;
  wireDemo(); wireTabbar();
  $('#signout').onclick = () => store.signOut();
}

/* ---------- Company rules ---------- */
function fillT(k, v) { return t(k).replace(/\{(\w+)\}/g, (m, x) => (v[x] ?? m)); }
function rulesList() {
  const sh = (n) => `${S.shifts[n].start}–${S.shifts[n].end}`;
  const items = [
    ['shift', 'r_shift', { s1: sh(1), s2: sh(2), s3: sh(3), lunch: `${S.lunch.start}–${S.lunch.end}` }],
    ['pin', 'r_geo', { r: S.factory.radius }],
    ['camera', 'r_selfie', {}],
    ['clock', 'r_grace', { g: S.graceMin }],
    ['hourglass', 'r_late', { free: S.lateFreeDays, n: S.lateFreeDays + 1 }],
    ['clipboard', 'r_work', {}],
    ['rupee', 'r_ot', { h: S.otThresholdH, x: S.otRateHigh }],
    ['calendar', 'r_off', { day: t(S.weeklyOff === 5 ? 'friday' : 'sunday') }],
    ['wallet', 'r_pay', { pf: +(S.pfRate * 100).toFixed(2), esi: +(S.esiRate * 100).toFixed(2) }],
    ['shield', 'r_honest', {}]
  ];
  return `<ol class="rules">${items.map(([i, k, v], n) => `<li><span class="rico">${ic(i)}</span><div><b>${n + 1}.</b> ${esc(fillT(k, v))}</div></li>`).join('')}</ol>`;
}
function rulesScreen() {
  workerFrame('rules');
  $('#main').innerHTML = `<div class="pagehead">${ic('book', 'lg')}<div><div class="tag">JAYCO</div><h1>${t('rulesTitle')}</h1></div></div>
    <p class="note">${t('rulesIntro')}</p><div class="card">${rulesList()}</div>
    ${ME && ME.rulesAccepted ? `<p class="pill ok">${ic('check', 'sm')} ${t('acceptRules')}</p>` : ''}`;
}

/* ---------- One-time guided tour ---------- */
const tourKey = () => 'jayco-tour-' + (ME && (ME.uid || ME.empId));
function showTour(force) {
  try { if (!force && localStorage.getItem(tourKey())) return; } catch (e) { if (!force) return; }
  const sh = myShift();
  const steps = [
    ['bearing', 't1h', 't1b'], ['shift', 't2h', 't2b'], ['pin', 't3h', 't3b'], ['clipboard', 't4h', 't4b'],
    ['logout', 't5h', 't5b'], ['wallet', 't6h', 't6b'], ['bell', 't7h', 't7b']
  ];
  const vars = { shift: sh ? shiftLabel(sh) : t('shiftNotSet'), g: S.graceMin, r: S.factory.radius };
  let i = 0;
  const m = document.createElement('div'); m.className = 'modal tour-modal'; m.setAttribute('role', 'dialog'); m.setAttribute('aria-modal', 'true');
  const done = () => { try { localStorage.setItem(tourKey(), '1'); } catch (e) {} m.remove(); };
  const draw = () => {
    const [icon, h, b] = steps[i], last = i === steps.length - 1;
    m.innerHTML = `<div class="sheet tour"><div class="tour-ic">${ic(icon, 'xl')}</div>
      <div class="tag">${i + 1} / ${steps.length}</div><h2>${t(h)}</h2><p>${esc(fillT(b, vars))}</p>
      <div class="dots">${steps.map((_, k) => `<i class="${k === i ? 'on' : ''}"></i>`).join('')}</div>
      <button class="btn" id="tn">${last ? t('tourStart') : t('tourNext')}</button>${last ? '' : `<button class="link" id="ts">${t('tourSkip')}</button>`}</div>`;
    m.querySelector('#tn').onclick = () => { if (last) done(); else { i++; draw(); } };
    const sk = m.querySelector('#ts'); if (sk) sk.onclick = done;
  };
  draw(); document.body.appendChild(m); m.querySelector('#tn').focus();
}

/* ---------- Boot ---------- */
async function boot() {
  const cfg = window.FIREBASE_CONFIG;
  store = cfg && cfg.apiKey ? makeFirebaseStore(cfg) : makeDemoStore();
  if ('serviceWorker' in navigator && location.protocol === 'https:') navigator.serviceWorker.register('sw.js').catch(() => {});
  store.onAuth(async (u) => {
    if (window.__creatingOwner) return;
    if (!u) { ME = null; return location.hash === '#hr' ? hrLogin() : workerLogin(); }
    try { S = await store.getSettings(); ME = await store.me(); }
    catch (e) { app.innerHTML = `<div class="pad"><p class="err">${esc(e.message)}</p></div>`; return; }
    if (ME && ME.active === false && (ME.status === 'pending' || ME.status === 'rejected')) return pendingScreen();
    if (!ME || ME.active === false) { toast(t('notActive'), 'bad'); return store.signOut(); }
    if (location.hash === '#hr' || ME.role === 'admin') { if (ME.role === 'worker') { location.hash = ''; return workerHome(); } return hrShell(); }
    workerHome();
  });
  window.addEventListener('hashchange', () => location.reload());
}

/* ---------- Worker: sign in ---------- */
function langPicker() {
  return `<div class="langs">${Object.keys(I18N).map(k => `<button class="chip" data-lang="${k}" aria-pressed="${k === LANG}">${I18N[k].lang}</button>`).join('')}</div>`;
}
function wireLang(rerender) {
  app.querySelectorAll('[data-lang]').forEach(b => b.onclick = () => { LANG = b.dataset.lang; document.documentElement.lang = LANG; try { localStorage.setItem('jayco-lang', LANG); } catch (e) {} rerender(); });
}
function workerLogin() {
  document.body.classList.add('wk');
  app.innerHTML = `${logoBar()}${demoBanner()}<main class="pad narrow">
    ${langPicker()}
    ${typeof iosInstallCard === 'function' ? iosInstallCard() : ''}
    <h1>${t('signin')}</h1>
    <form id="f" class="stack">
      <label>${t('idOrMobile')}<input id="emp" inputmode="numeric" autocomplete="username" required></label>
      <label>${t('pin')}<input id="pin" type="password" inputmode="numeric" maxlength="6" minlength="6" autocomplete="current-password" required></label>
      <button class="btn" id="go">${t('signinBtn')}</button>
      ${store.mode === 'demo' ? '<p class="note">Demo: employee ID 0417, PIN 111111</p>' : ''}
    </form>
    <p class="note center"><button class="link" id="forgot">${t('forgotPin')}</button></p>
    <button class="btn ghost" id="reg">${t('newWorker')}</button>
    <p class="note center"><a href="#hr">HR / owner sign in</a></p></main>`;
  wireLang(workerLogin); wireDemo();
  if (typeof iosInstallGuide === 'function') iosInstallGuide();
  $('#reg').onclick = registerForm;
  $('#forgot').onclick = forgotPinForm;
  $('#f').onsubmit = async (e) => {
    e.preventDefault(); const b = $('#go'); busy(b, true);
    try { await store.signInWorker($('#emp').value, $('#pin').value); }
    catch (err) { busy(b, false); toast(!navigator.onLine || err.code === 'auth/network-request-failed' ? t('offline') : err.code === 'auth/too-many-requests' ? t('tooMany') : t('wrongPin'), 'bad'); }
  };
}

/* ---------- Location ---------- */
function getLocation(onUpdate) {
  // Try precise GPS first; if it times out or is unavailable, fall back to network location.
  let best = null, done = false, id = null, tries = 0;
  const finish = () => { done = true; if (id != null) navigator.geolocation.clearWatch(id); id = null; };
  if (!navigator.geolocation) { onUpdate({ error: 'nogeo' }); return finish; }
  const ok = (p) => {
    if (done) return;
    const c = p.coords;
    if (!best || c.accuracy < best.acc) {
      const dist = RULES.distanceM(c.latitude, c.longitude, S.factory.lat, S.factory.lng);
      best = { lat: c.latitude, lng: c.longitude, acc: Math.round(c.accuracy), dist: Math.round(dist) };
      onUpdate(best);
    }
    if (best.acc <= 20) finish();
  };
  const fail = (e) => {
    if (done || best) return;                     // keep a good reading; ignore later timeouts
    if (e && e.code === 1) { finish(); return onUpdate({ error: 'denied' }); }
    if (tries++ === 0) {                            // one retry without high accuracy (indoors, weak GPS)
      if (id != null) navigator.geolocation.clearWatch(id);
      id = navigator.geolocation.watchPosition(ok, fail, { enableHighAccuracy: false, maximumAge: 60000, timeout: 20000 });
      return;
    }
    finish(); onUpdate({ error: 'nofix' });
  };
  id = navigator.geolocation.watchPosition(ok, fail, { enableHighAccuracy: true, maximumAge: 0, timeout: 20000 });
  setTimeout(() => { if (!best && !done) fail({ code: 3 }); }, 25000);
  setTimeout(() => { if (!done) finish(); }, 60000);
  return finish;
}
/* Keeps trying until the phone gives a location: every 8 s while blocked, at once when the worker
   comes back to the app (after changing a setting) and when the permission changes. Only one runs at a time. */
let LOCRUN = 0;
function watchLoc(onUpdate) {
  const run = ++LOCRUN; let stop = null, timer = null, last = null, perm = null;
  const alive = () => run === LOCRUN && document.getElementById('main');
  const cleanup = () => { clearInterval(timer); document.removeEventListener('visibilitychange', onVis); if (stop) stop(); };
  const attempt = (quiet) => {
    if (!alive()) return cleanup();
    if (stop) stop();
    if (!quiet) onUpdate(null);
    stop = getLocation(async (u) => {
      if (!alive()) return cleanup();
      if (u && u.error) {
        try { if (navigator.permissions) { const st = await navigator.permissions.query({ name: 'geolocation' }); perm = st.state;
          if (!st._jw) { st._jw = 1; st.onchange = () => { if (alive()) attempt(true); }; } } } catch (e) {}
        // Permission is granted but no location comes: the phone's Location (GPS) switch is off.
        if (perm === 'granted' && (u.error === 'denied' || u.error === 'nofix')) u = { error: 'gpsoff' };
        if (last && last.error && !(u.error !== last.error)) return;   // same error: keep the screen still
      }
      last = u; onUpdate(u);
    });
  };
  const onVis = () => { if (document.visibilityState === 'visible' && last && (last.error || !locOk(last))) attempt(true); };
  document.addEventListener('visibilitychange', onVis);
  timer = setInterval(() => { if (!alive()) return cleanup(); if (last && last.error && document.visibilityState === 'visible') attempt(true); }, 8000);
  attempt(false);
}
const maxAcc = () => S.maxAccuracy || 60;
const locOk = (L) => L && !L.error && L.dist <= S.factory.radius && L.acc <= maxAcc();

function locCard(L) {
  if (!L) return `<div class="card"><div class="tag">${t('location')}</div><p>${t('checking')}</p></div>`;
  if (L.error === 'denied') {
    const steps = (typeof IS_IOS !== 'undefined' && IS_IOS) ? iosT('locSteps') : (I18N[LANG].locSteps || I18N.en.locSteps);
    const android = /Android/i.test(navigator.userAgent);
    // Opens this same site in the full Chrome browser (shares the login), where Chrome asks for location itself.
    const chromeUrl = `intent://${location.host}${location.pathname}#Intent;scheme=https;package=com.android.chrome;S.browser_fallback_url=${encodeURIComponent(location.origin + '/')};end`;
    return `<div class="card"><div class="tag">${t('location')}</div><p class="err">${t('locDenied')}</p>
      <ol class="steps">${steps.map(x => `<li>${esc(x)}</li>`).join('')}</ol>
      <div class="note">${t('locAuto')}</div>
      <button class="btn ghost" id="loc-retry">${t('retry')}</button>
      ${android ? `<a class="btn ghost" href="${esc(chromeUrl)}">${t('openChrome')}</a>` : ''}</div>`;
  }
  if (L.error === 'gpsoff') return `<div class="card"><div class="tag">${t('location')}</div><p class="err">${t('locGpsOff')}</p>
    <div class="note">${t('locAuto')}</div><button class="btn ghost" id="loc-retry">${t('retry')}</button></div>`;
  if (L.error) return `<div class="card"><div class="tag">${t('location')}</div><p class="err">${t(L.error === 'nofix' ? 'locNoFix' : 'locErr')}</p>
    <button class="btn ghost" id="loc-retry">${t('retry')}</button>${store.mode === 'demo' ? '<button class="btn ghost" id="loc-demo">Demo: use factory location</button>' : ''}</div>`;
  const ok = locOk(L), weak = L.acc > maxAcc();
  return `<div class="card"><div class="row"><div><div class="tag">${t('location')}</div><div class="big">${L.dist} m</div></div>
    <span class="pill ${ok ? 'ok' : 'bad'}">${ok ? t('inside') : t('outside')}</span></div>
    <div class="note">${weak ? t('accuracyLow') : ''} GPS ±${L.acc} m · ${S.factory.radius} m zone</div>
    ${ok ? '' : `<button class="btn ghost" id="loc-retry">${t('retry')}</button>`}</div>`;
}

/* ---------- Selfie ---------- */
function selfieModal(stampLines) {
  return new Promise((resolve) => {
    const m = document.createElement('div'); m.className = 'modal';
    m.innerHTML = `<div class="sheet"><div class="cam"><video id="v" playsinline autoplay muted></video><canvas id="c" hidden></canvas><div class="oval"></div></div>
      <p class="note center" id="hint">${t('faceHint')}</p>
      <input type="file" id="file" accept="image/*" capture="user" hidden>
      <div class="stack" id="acts"><button class="btn" id="snap">${t('takeSelfie')}</button><button class="btn ghost" id="cancel">${t('back')}</button></div></div>`;
    document.body.appendChild(m);
    const v = $('#v', m), c = $('#c', m); let stream = null, shot = null;
    const stop = () => stream && stream.getTracks().forEach(x => x.stop());
    const close = (val) => { stop(); m.remove(); resolve(val); };
    const draw = (src, w, h) => {
      const W = 360, H = 480; c.width = W; c.height = H; const ctx = c.getContext('2d');
      const r = Math.max(W / w, H / h), dw = w * r, dh = h * r;
      ctx.save(); ctx.translate(W, 0); ctx.scale(-1, 1); ctx.drawImage(src, (W - dw) / 2, (H - dh) / 2, dw, dh); ctx.restore();
      ctx.fillStyle = 'rgba(0,0,0,.6)'; ctx.fillRect(0, H - 46, W, 46); ctx.fillStyle = '#fff'; ctx.font = '13px monospace';
      stampLines.forEach((l, i) => ctx.fillText(l, 8, H - 28 + i * 17));
      shot = c.toDataURL('image/jpeg', 0.6); c.hidden = false; v.hidden = true; stop();
      $('#acts', m).innerHTML = `<button class="btn" id="ok">${t('takeSelfie')} ✓</button><button class="btn ghost" id="again">${t('retake')}</button>`;
      $('#ok', m).onclick = () => close(shot);
      $('#again', m).onclick = () => { m.remove(); stop(); selfieModal(stampLines).then(resolve); };
    };
    $('#cancel', m).onclick = () => close(null);
    $('#file', m).onchange = (e) => {
      const f = e.target.files[0]; if (!f) return; const img = new Image();
      img.onload = () => draw(img, img.naturalWidth, img.naturalHeight); img.src = URL.createObjectURL(f);
    };
    const fallback = () => { $('#hint', m).textContent = t('camErr'); $('#snap', m).textContent = t('openCam'); $('#snap', m).onclick = () => $('#file', m).click(); };
    $('#snap', m).onclick = () => { if (v.videoWidth) draw(v, v.videoWidth, v.videoHeight); else v.addEventListener('loadeddata', () => draw(v, v.videoWidth, v.videoHeight), { once: true }); };
    if (navigator.mediaDevices && navigator.mediaDevices.getUserMedia) {
      navigator.mediaDevices.getUserMedia({ video: { facingMode: 'user', width: { ideal: 720 } }, audio: false })
        .then(s => { stream = s; v.setAttribute('playsinline', ''); v.muted = true; v.srcObject = s; const p = v.play(); if (p && p.catch) p.catch(() => {}); })
        .catch((err) => { fallback(); if (err && err.name === 'NotAllowedError' && typeof IS_IOS !== 'undefined' && IS_IOS) $('#hint', m).textContent = iosT('camSteps'); });
    } else fallback();
  });
}

/* ---------- Worker: home ---------- */
async function workerHome() {
  const date = todayIST();
  workerFrame('home'); $('#main').innerHTML = `<p>${t('checking')}</p>`;
  let rec, month;
  try { [rec, month] = await Promise.all([store.getDay(ME.empId, date), store.monthList(monthIST(), ME.empId)]); }
  catch (e) { console.error(e); $('#main').innerHTML = `<p class="err">${navigator.onLine ? esc(e.code || e.message || String(e)) : t('offline')}</p><button class="btn" onclick="location.reload()">${t('retry')}</button>`; return; }
  const results = month.filter(r => r.outAt).map(r => RULES.dayResult(S, r.shift, minOfDayIST(r.inAt), minOfDayIST(r.outAt)));
  const otMin = results.reduce((a, r) => a + r.otMin, 0), lateDays = results.filter(r => r.isLate).length;
  const monthCard = `<div class="card"><div class="row"><span class="tag">${t('otMonth')}</span><span class="pill ${otMin >= S.otThresholdH * 60 ? 'ok' : 'warn'}">${RULES.fmtMin(otMin)}</span></div>
    <div class="note">${t('otHint')}</div><div class="row"><span class="tag">${t('lateMonth')}</span><span class="mono">${lateDays} / ${S.lateFreeDays}</span></div></div>${reminderCard()}`;
  const head = `<section class="hero"><div class="hero-row"><div class="avatar hero-av">${ME.photo ? `<img src="${ME.photo}" alt="">` : ic('user', 'lg')}</div>
    <div class="grow"><div class="hero-hi">${t('hello')}</div><h1>${esc(ME.name)}</h1><div class="hero-sub">EMP ${esc(ME.empId)}${ME.dept ? ' · ' + esc(ME.dept) : ''}</div></div></div>
    <div class="hero-chips"><span class="chip-l">${ic('shift', 'sm')} ${myShift() ? shiftLabel(myShift()) : t('shiftNotSet').split('.')[0]}</span>
    <span class="chip-l">${ic('calendar', 'sm')} ${esc(new Date(date + 'T12:00:00+05:30').toLocaleDateString(LANG === 'en' ? 'en-IN' : LANG + '-IN', { weekday: 'short', day: 'numeric', month: 'short' }))}</span>
    ${ME.role === 'supervisor' ? `<a class="chip-l" href="#hr">${ic('check', 'sm')} Approve work</a>` : ''}</div></section>`;
  const offToday = new Date(date + 'T12:00:00+05:30').getDay() === S.weeklyOff;
  let body = '';

  if (!rec) {
    const fixed = myShift();
    let shift = fixed || Number(sessionStorageGet('jayco-shift')) || 1, L = null;
    const render = () => {
      $('#main').innerHTML = `${head}${offToday ? `<div class="pill warn">${t('weeklyOff')}</div>` : ''}
        ${fixed ? `<div class="card shiftfix"><span class="rico big-ico">${ic('shift')}</span><div class="grow"><div class="tag">${t('yourShift')}</div><div class="big">${S.shifts[fixed].start}–${S.shifts[fixed].end}</div><div class="note">${t('shift')} ${fixed} · ${t('lunch')}</div></div></div>`
        : `<div class="card"><div class="tag">${t('chooseShift')}</div><div class="shifts">${[1, 2, 3].map(n => `<button data-shift="${n}" aria-pressed="${n === shift}"><b>${t('shift')} ${n}</b>${S.shifts[n].start}–${S.shifts[n].end}</button>`).join('')}</div>
        <div class="note">${t('shiftNotSet')}</div></div>`}
        ${locCard(L)}
        <button class="btn btn-ic" id="in" ${locOk(L) ? '' : 'disabled'}>${ic('camera')} ${t('checkin')}</button>${monthCard}`;
      app.querySelectorAll('[data-shift]').forEach(b => b.onclick = () => { shift = +b.dataset.shift; sessionStorageSet('jayco-shift', shift); render(); });
      const r = $('#loc-retry'); if (r) r.onclick = () => { L = null; render(); watchLoc(u => { L = u; render(); }); };
      const dm = $('#loc-demo'); if (dm) dm.onclick = () => { L = { lat: S.factory.lat, lng: S.factory.lng, acc: 10, dist: 8 }; render(); };
      wireWorkerExtras();
      $('#in').onclick = async () => {
        const now = new Date();
        const pic = await selfieModal([`JAYCO ${ME.empId} ${esc(ME.name)}`.slice(0, 40), `${date} ${hhmm(now)} IN · ${L.dist} m`]);
        if (!pic) return;
        const b = $('#in'); busy(b, true);
        try {
          await store.checkIn({ empId: ME.empId, uid: ME.uid, name: ME.name, date, month: date.slice(0, 7), shift, inLat: L.lat, inLng: L.lng, inAcc: L.acc, inDist: L.dist, workStatus: 'none' }, pic);
          store.setPushInfo({ empId: ME.empId, shift, lang: LANG });
          workerHome();
        } catch (e) { busy(b, false); toast(navigator.onLine ? e.message : t('offline'), 'bad'); }
      };
    };
    render(); watchLoc(u => { L = u; render(); }); showTour();
    return;
  }

  if (rec && !rec.outAt) {
    const d = RULES.dayResult(S, rec.shift, minOfDayIST(rec.inAt), minOfDayIST(new Date()));
    let L = null;
    const hasWork = rec.work && rec.work.op;
    const render = () => {
      $('#main').innerHTML = `${head}
        <div class="card"><div class="row"><span class="tag">${t('checkedIn')}</span><span class="pill ${d.isLate ? 'warn' : 'ok'}">${d.isLate ? t('late') + ' ' + d.lateMin + 'm' : t('onTime')}</span></div>
          <div class="big">${hhmm(rec.inAt)}</div><div class="note">${t('shift')} ${rec.shift}: ${S.shifts[rec.shift].start}–${S.shifts[rec.shift].end}</div></div>
        <div class="card"><div class="row"><span class="tag">${t('workedSoFar')}</span><span class="big">${RULES.fmtMin(d.workedMin)}</span></div></div>
        ${hasWork ? `<div class="card"><div class="row"><span class="tag">${t('workSaved')}</span><button class="link" id="edit-work">✎</button></div><div>${esc(rec.work.part)} · ${esc(rec.work.op)} · ${esc(rec.work.qty)}</div></div>
          ${locCard(L)}<button class="btn btn-ic" id="out" ${locOk(L) ? '' : 'disabled'}>${ic('logout')} ${t('checkout')}</button>`
        : `<button class="btn btn-ic" id="work">${ic('clipboard')} ${t('writeWork')}</button>`}
        ${monthCard}`;
      wireWorkerExtras();
      const w = $('#work') || $('#edit-work'); if (w) w.onclick = () => workForm(rec);
      const r = $('#loc-retry'); if (r) r.onclick = () => { L = null; render(); watchLoc(u => { L = u; render(); }); };
      const dm = $('#loc-demo'); if (dm) dm.onclick = () => { L = { lat: S.factory.lat, lng: S.factory.lng, acc: 10, dist: 14 }; render(); };
      const o = $('#out'); if (o) o.onclick = async () => {
        const now = new Date();
        const pic = await selfieModal([`JAYCO ${ME.empId} ${esc(ME.name)}`.slice(0, 40), `${date} ${hhmm(now)} OUT · ${L.dist} m`]);
        if (!pic) return; busy(o, true);
        try { await store.checkOut(ME.empId, date, { outLat: L.lat, outLng: L.lng, outAcc: L.acc, outDist: L.dist }, pic); workerHome(); }
        catch (e) { busy(o, false); toast(navigator.onLine ? e.message : t('offline'), 'bad'); }
      };
    };
    render(); if (hasWork) watchLoc(u => { L = u; render(); }); showTour();
    return;
  }

  const d = RULES.dayResult(S, rec.shift, minOfDayIST(rec.inAt), minOfDayIST(rec.outAt));
  body = `${head}<div class="card"><div class="row"><span class="tag">${t('checkedOut')}</span><span class="pill ok">✓</span></div>
    <div class="row"><div><div class="tag">${t('in')}</div><div class="big">${hhmm(rec.inAt)}</div></div><div><div class="tag">${t('out')}</div><div class="big">${hhmm(rec.outAt)}</div></div></div>
    <div class="note">${t('worked')} ${RULES.fmtMin(d.workedMin)} · ${t('ot')} ${RULES.fmtMin(d.otMin)}</div></div>
    <p>${t('dayDone')}</p>${monthCard}
    <button class="btn ghost" id="pin-btn">${t('changePin')}</button>`;
  $('#main').innerHTML = body; wireWorkerExtras(); showTour();
  $('#pin-btn').onclick = () => {
    $('#pin-btn').outerHTML = `<form id="pf" class="row"><input id="np" type="password" inputmode="numeric" minlength="6" maxlength="6" autocomplete="new-password" placeholder="${t('newPin')}" required><button class="btn small">OK</button></form>`;
    $('#pf').onsubmit = async (e) => { e.preventDefault(); try { await store.changePin($('#np').value); toast(t('pinChanged'), 'ok'); $('#pf').remove(); } catch (err) { toast(err.message, 'bad'); } };
  };
}
/* ---------- Worker: reminders and pay ---------- */
const pushPerm = () => ('Notification' in window) ? Notification.permission : 'unsupported';
function reminderCard() {
  const p = pushPerm();
  if (p === 'unsupported' && typeof iosNeedsInstall === 'function' && iosNeedsInstall()) return iosInstallCard(iosT('remIos'));
  if (p === 'unsupported' || p === 'granted') return '';
  return `<div class="card" id="rem"><div class="tag">${t('reminders')}</div><div class="note">${p === 'denied' ? t('remindersBlocked') : t('remindersHint')}</div>
    ${p === 'denied' ? '' : `<button class="btn ghost" id="rem-on">${t('remindersBtn')}</button>`}</div>`;
}
let pushSynced = false;
function wireWorkerExtras() {
  const mp = $('#mypay'); if (mp) mp.onclick = () => payScreen(monthIST());
  const info = () => ({ empId: ME.empId, name: ME.name, lang: LANG, shift: myShift() || Number(sessionStorageGet('jayco-shift')) || undefined });
  const clean = (o) => { Object.keys(o).forEach(k => o[k] === undefined && delete o[k]); return o; };
  const b = $('#rem-on');
  if (b) b.onclick = async () => {
    busy(b, true);
    try { await store.enablePush(clean(info())); toast(t('remindersOn'), 'ok'); $('#rem').remove(); }
    catch (e) { busy(b, false); toast(pushPerm() === 'denied' ? t('remindersBlocked') : (e.code || e.message), 'bad'); }
  };
  // Keep this phone's reminder token fresh once per app start.
  if (!pushSynced && pushPerm() === 'granted') { pushSynced = true; store.enablePush(clean(info())).catch(() => {}); }
}

async function payScreen(month) {
  workerFrame('pay'); $('#main').innerHTML = `<p>${t('checking')}</p>`;
  let list, adv, loans;
  try { [list, adv, loans] = await Promise.all([store.monthList(month, ME.empId), store.advances(month, ME.empId), store.loans(ME.empId)]); }
  catch (e) { $('#main').innerHTML = `<p class="err">${esc(e.code || e.message)}</p><button class="btn ghost" id="pb">${t('back')}</button>`; $('#pb').onclick = () => workerHome(); return; }
  const days = list.filter(r => r.outAt).map(r => RULES.dayResult(S, r.shift, minOfDayIST(r.inAt), minOfDayIST(r.outAt)));
  const advTotal = adv.reduce((a, x) => a + Number(x.amount || 0), 0);
  const lr = loans.filter(l => l.startMonth <= month && !loanDoneBefore(l, month)).map(l => ({ l, r: RULES.loanForMonth(l, month) }));
  const loanCut = lr.reduce((a, { r }) => a + r.due, 0);
  const p = RULES.monthPay(S, days, Number(ME.dailyWage || 0), advTotal, ME.pfEsi !== false, loanCut);
  const [y, m] = month.split('-').map(Number);
  const prev = new Date(Date.UTC(y, m - 2, 1)).toISOString().slice(0, 7), next = new Date(Date.UTC(y, m, 1)).toISOString().slice(0, 7);
  const label = new Date(Date.UTC(y, m - 1, 1)).toLocaleDateString(LANG === 'en' ? 'en-IN' : LANG + '-IN', { month: 'long', year: 'numeric', timeZone: 'UTC' });
  const line = (k, v, cls = '') => `<div class="row"><span>${k}</span><span class="num ${cls}">${v}</span></div>`;
  $('#main').innerHTML = `<div class="pagehead">${ic('wallet', 'lg')}<div><div class="tag">${t('myPay')}</div><h1>${t('payTitle')}</h1></div></div>
    <div class="row"><button class="btn ghost small" id="pm">‹</button><b>${esc(label)}</b><button class="btn ghost small" id="nm" ${month >= monthIST() ? 'disabled' : ''}>›</button></div>
    <div class="card paycard"><span class="tag">${t('netPay')}</span><div class="paybig">${inr(p.net)}</div><div class="note">${t('payEstimate')}</div></div>
    <div class="card">
      ${line(t('wagePerDay'), inr(ME.dailyWage))}
      ${line(t('daysPresent'), p.daysPresent)}
      ${line(t('wages'), inr(p.wages))}
      ${line(t('otHours') + (p.mult > 1 ? ' (' + p.mult + 'x)' : ''), p.otPaidH + ' h')}
      ${line(t('otPay'), inr(p.otPay))}
      ${p.lateCut ? line(t('lateCut'), '− ' + inr(p.lateCut), 'err') : ''}
      ${line(t('gross'), inr(p.gross))}
      ${p.pf ? line(t('pf'), '− ' + inr(p.pf)) : ''}
      ${p.esi ? line(t('esi'), '− ' + inr(p.esi)) : ''}
      ${line(t('advances'), advTotal ? '− ' + inr(advTotal) : inr(0))}
      ${loanCut ? line(t('loanInst'), '− ' + inr(loanCut)) : ''}
    </div>
    ${lr.length ? `<div class="card"><span class="tag">${t('loanTitle')}</span>
      ${lr.map(({ l, r }) => `${l.note ? `<div class="note">${esc(l.note)}</div>` : ''}
        ${line(t('loanTaken'), inr(l.amount))}${line(t('loanMonthly'), inr(l.instalment))}
        ${line(t('loanRepaid'), inr(r.paidBefore + r.due))}
        ${line('<b>' + t('loanBalance') + '</b>', '<b>' + inr(r.balance) + '</b>')}
        ${r.settled ? `<div class="note">${t('loanSettled')}</div>` : r.balance ? line(t('loanMonthsLeft'), r.monthsLeft) : `<div class="note">${t('loanDone')}</div>`}`).join('<hr>')}
    </div>` : ''}
    <div class="card"><span class="tag">${t('advances')}</span>
      ${adv.length ? adv.map(a => line(esc(a.note || t('advances')), inr(a.amount))).join('') : `<div class="note">${t('noAdvances')}</div>`}</div>`;
  $('#pm').onclick = () => payScreen(prev);
  $('#nm').onclick = () => payScreen(next);
}

// A loan stops showing in My pay once it was fully repaid (or settled) in an earlier month.
function loanDoneBefore(l, month) {
  const [y, m] = month.split('-').map(Number);
  const prev = new Date(Date.UTC(y, m - 2, 1)).toISOString().slice(0, 7);
  return prev >= l.startMonth && RULES.loanForMonth(l, prev).balance === 0;
}

function sessionStorageGet(k) { try { return sessionStorage.getItem(k); } catch (e) { return null; } }
function sessionStorageSet(k, v) { try { sessionStorage.setItem(k, v); } catch (e) {} }

function workForm(rec) {
  const w = rec.work || {};
  $('#main').innerHTML = `<div><div class="tag">${t('writeWork')}</div><h1>${t('workTitle')}</h1></div>
    <form id="wf" class="stack">
      <label>${t('part')}<select id="w-part">${PARTS.map(p => `<option ${p === w.part ? 'selected' : ''}>${p}</option>`).join('')}</select></label>
      <label>${t('op')}<input id="w-op" value="${esc(w.op)}" required></label>
      <div class="row"><label class="grow">${t('machine')}<input id="w-mc" value="${esc(w.machine)}"></label><label class="qty">${t('qty')}<input id="w-qty" type="number" min="0" inputmode="numeric" value="${esc(w.qty)}" required></label></div>
      <label>${t('notes')}<textarea id="w-notes">${esc(w.notes)}</textarea></label>
      <button class="btn" id="ws">${t('saveWork')}</button><button type="button" class="btn ghost" id="wb">${t('back')}</button>
    </form>`;
  $('#wb').onclick = () => workerHome();
  $('#wf').onsubmit = async (e) => {
    e.preventDefault();
    const work = { part: $('#w-part').value, op: $('#w-op').value.trim(), qty: Number($('#w-qty').value), machine: $('#w-mc').value.trim(), notes: $('#w-notes').value.trim() };
    if (!work.op || !$('#w-qty').value) return toast(t('workNeeded'), 'bad');
    const b = $('#ws'); busy(b, true);
    try { await store.saveWork(ME.empId, rec.date, work); toast(t('workSaved'), 'ok'); workerHome(); }
    catch (err) { busy(b, false); toast(navigator.onLine ? err.message : t('offline'), 'bad'); }
  };
}

/* ---------- Worker: self registration ---------- */
function registerForm() {
  document.body.classList.add('wk');
  let photo = null, shift = 0, accepted = false;
  if (!S) S = { ...RULES.DEFAULTS };
  const render = () => {
    app.innerHTML = `${logoBar()}${demoBanner()}<main class="pad narrow">${langPicker()}
      <h1>${t('regTitle')}</h1>
      <form id="rf" class="stack">
        <div class="row"><div class="avatar">${photo ? `<img src="${photo}" alt="">` : ''}</div><button type="button" class="btn ghost small" id="ph">${t('takePhoto')}</button></div>
        <label>${t('fullName')}<input id="r-name" required autocomplete="name"></label>
        <label>${t('mobile')}<input id="r-mob" inputmode="numeric" maxlength="10" required autocomplete="tel"></label>
        <label>${t('dept')}<input id="r-dept"></label>
        <fieldset class="card"><legend class="tag">${t('chooseShiftOnce')}</legend><div class="shifts">${[1, 2, 3].map(n => `<button type="button" data-shift="${n}" aria-pressed="${n === shift}"><b>${t('shift')} ${n}</b>${S.shifts[n].start}–${S.shifts[n].end}</button>`).join('')}</div>
          <div class="note">${t('chooseShiftHint')}</div></fieldset>
        <label>${t('choosePin')}<input id="r-pin" type="password" inputmode="numeric" maxlength="6" minlength="6" required autocomplete="new-password"></label>
        <label>${t('pin2')}<input id="r-pin2" type="password" inputmode="numeric" maxlength="6" minlength="6" required autocomplete="new-password"></label>
        <div class="card"><div class="pagehead">${ic('book', 'lg')}<div><div class="tag">JAYCO</div><h2>${t('rulesTitle')}</h2></div></div>
          <p class="note">${t('rulesIntro')}</p><div class="rulesbox">${rulesList()}</div>
          <label class="tick"><input type="checkbox" id="r-ok" ${accepted ? 'checked' : ''}> <span>${t('acceptRules')}</span></label></div>
        <button class="btn" id="rs" ${accepted ? '' : 'disabled'}>${t('register')}</button>
      </form><p class="note center"><button class="link" id="back">${t('haveAccount')}</button></p></main>`;
    wireLang(() => { const v = keep(); render(); fill(v); }); wireDemo();
    $('#back').onclick = workerLogin;
    app.querySelectorAll('[data-shift]').forEach(b => b.onclick = () => { const v = keep(); shift = +b.dataset.shift; render(); fill(v); });
    $('#r-ok').onchange = (e) => { accepted = e.target.checked; $('#rs').disabled = !accepted; };
    $('#ph').onclick = async () => { const v = keep(); const p = await selfieModal(['JAYCO profile', todayIST()]); if (p) photo = await shrink(p, 160); render(); fill(v); };
    $('#rf').onsubmit = async (e) => {
      e.preventDefault();
      const mob = $('#r-mob').value.replace(/\D/g, '');
      if (!/^[6-9][0-9]{9}$/.test(mob)) return toast(t('mobileErr'), 'bad');
      if ($('#r-pin').value !== $('#r-pin2').value || !/^[0-9]{6}$/.test($('#r-pin').value)) return toast(t('pinMismatch'), 'bad');
      if (!photo) return toast(t('photoNeeded'), 'bad');
      if (!shift) return toast(t('shiftNeeded'), 'bad');
      if (!accepted) return toast(t('rulesNeeded'), 'bad');
      const b = $('#rs'); busy(b, true);
      try { await store.registerSelf({ name: $('#r-name').value.trim(), mobile: mob, dept: $('#r-dept').value.trim(), photo, shift }, $('#r-pin').value); }
      catch (err) { busy(b, false); toast(err.code === 'auth/email-already-in-use' ? t('mobileUsed') : (navigator.onLine ? err.message : t('offline')), 'bad'); }
    };
  };
  const keep = () => ['r-name', 'r-mob', 'r-dept'].map(id => ($('#' + id) || {}).value || '');
  const fill = (v) => ['r-name', 'r-mob', 'r-dept'].forEach((id, i) => { $('#' + id).value = v[i]; });
  render();
}
/* ---------- Worker: forgot PIN ---------- */
function forgotPinForm() {
  let photo = null;
  const keep = () => ['f-mob'].map(id => ($('#' + id) || {}).value || '');
  const render = (v = ['']) => {
    app.innerHTML = `${logoBar()}${demoBanner()}<main class="pad narrow">${langPicker()}
      <h1>${t('resetTitle')}</h1><p class="note">${t('resetHint')}</p>
      <form id="ff" class="stack">
        <label>${t('mobile')}<input id="f-mob" inputmode="numeric" maxlength="10" required autocomplete="tel"></label>
        <label>${t('newPin')}<input id="f-pin" type="password" inputmode="numeric" maxlength="6" minlength="6" required autocomplete="new-password"></label>
        <label>${t('pin2')}<input id="f-pin2" type="password" inputmode="numeric" maxlength="6" minlength="6" required autocomplete="new-password"></label>
        <div class="row"><div class="avatar">${photo ? `<img src="${photo}" alt="">` : ''}</div><button type="button" class="btn ghost small" id="ph">${t('takePhoto')}</button></div>
        <button class="btn" id="fs">${t('resetSend')}</button>
      </form><p class="note center"><button class="link" id="back">${t('haveAccount')}</button></p></main>`;
    $('#f-mob').value = v[0];
    wireLang(() => render(keep())); wireDemo();
    $('#back').onclick = workerLogin;
    $('#ph').onclick = async () => { const k = keep(); const p = await selfieModal(['JAYCO PIN reset', todayIST()]); if (p) photo = await shrink(p, 160); render(k); };
    $('#ff').onsubmit = async (e) => {
      e.preventDefault();
      const mob = $('#f-mob').value.replace(/\D/g, '');
      if (!/^[6-9][0-9]{9}$/.test(mob)) return toast(t('mobileErr'), 'bad');
      if ($('#f-pin').value !== $('#f-pin2').value || !/^[0-9]{6}$/.test($('#f-pin').value)) return toast(t('pinMismatch'), 'bad');
      if (!photo) return toast(t('photoNeeded'), 'bad');
      const b = $('#fs'); busy(b, true);
      try {
        await store.requestPinReset(mob, $('#f-pin').value, photo);
        app.innerHTML = `${logoBar()}<main class="pad narrow stack"><div class="card center stack">
          <span class="pill warn">${t('waiting')}</span><h1>${t('resetSent')}</h1><p class="note">${t('resetSentHint')}</p></div>
          <button class="btn" id="ok">${t('signin')}</button></main>`;
        $('#ok').onclick = workerLogin;
      } catch (err) { busy(b, false); toast(navigator.onLine ? err.message : t('offline'), 'bad'); }
    };
  };
  render();
}
function shrink(dataUrl, size) {
  return new Promise((res) => { const img = new Image(); img.onload = () => {
    const c = document.createElement('canvas'); c.width = size; c.height = Math.round(size * 4 / 3);
    const ctx = c.getContext('2d'); const r = Math.max(c.width / img.width, c.height / img.height);
    ctx.drawImage(img, (c.width - img.width * r) / 2, (c.height - img.height * r) / 2, img.width * r, img.height * r);
    res(c.toDataURL('image/jpeg', 0.7)); }; img.src = dataUrl; });
}
function pendingScreen() {
  const rej = ME.status === 'rejected';
  app.innerHTML = `${logoBar()}${demoBanner()}<main class="pad narrow stack">${langPicker()}
    <div class="card center stack">${ME.photo ? `<div class="avatar big"><img src="${ME.photo}" alt=""></div>` : ''}
      <h1>${esc(ME.name)}</h1><div class="note">${esc(ME.phone || '')}</div>
      <span class="pill ${rej ? 'bad' : 'warn'}">${rej ? t('rejected') : t('waiting')}</span>
      ${rej ? '' : `<p class="note">${t('waitingHint')}</p>`}</div>
    <button class="btn ghost" id="again">${t('retry')}</button><button class="link" id="signout">${t('signout')}</button></main>`;
  wireLang(pendingScreen); wireDemo();
  $('#again').onclick = () => location.reload();
  $('#signout').onclick = () => store.signOut();
}
