/* HR panel: Today, Work records, Payroll, Workers, Settings. English only. */
const TABS = [['today', 'Today'], ['work', 'Work records'], ['payroll', 'Payroll'], ['workers', 'Workers'], ['settings', 'Settings']];
let TAB = 'today';
try { TAB = sessionStorage.getItem('jayco-tab') || 'today'; } catch (e) {}

function hrLogin() {
  app.innerHTML = `${logoBar()}${demoBanner()}<main class="pad narrow"><h1>HR / owner sign in</h1>
    <form id="f" class="stack">
      <label>Email<input id="em" type="email" autocomplete="username" required></label>
      <label>Password<input id="pw" type="password" autocomplete="current-password" minlength="6" required></label>
      <button class="btn" id="go">Sign in</button>
      ${store.mode === 'demo' ? '<p class="note">Demo: hr@demo, password demo123</p>' : '<button type="button" class="btn ghost" id="owner">First time: create owner account</button>'}
    </form><p class="note center"><button type="button" class="link" id="forgot">Forgot password?</button> · <a href="#">Worker sign in</a></p></main>`;
  wireDemo();
  $('#f').onsubmit = async (e) => {
    e.preventDefault(); const b = $('#go'); b.disabled = true;
    try { await store.signInAdmin($('#em').value.trim(), $('#pw').value); } catch (err) { b.disabled = false; toast('Wrong email or password', 'bad'); }
  };
  $('#forgot').onclick = async () => {
    const em = $('#em').value.trim();
    if (!em) return toast('Type your email above first, then tap Forgot password.', 'bad');
    try { await store.resetPassword(em); toast('Password reset email sent. Check your inbox (and Spam).', 'ok'); }
    catch (err) { toast(err.code === 'auth/invalid-email' ? 'That email address is not valid.' : err.code === 'auth/too-many-requests' ? 'Too many tries. Wait a few minutes and try again.' : (err.message || 'Could not send the email.'), 'bad'); }
  };
  const o = $('#owner'); if (o) o.onclick = async () => {
    const em = $('#em').value.trim(), pw = $('#pw').value;
    if (!em || pw.length < 6) return toast('Enter your owner email and a password of 6 or more characters first.', 'bad');
    try { await store.createOwner(em, pw, 'Owner'); toast('Owner account created', 'ok'); }
    catch (err) { toast(err.code === 'permission-denied' ? 'Only the owner email set up for JAYCO can create this account.' : err.message, 'bad'); }
  };
}

function hrShell() {
  app.innerHTML = `${logoBar(`<span>${esc(ME.name)} · ${esc(ME.role)}</span><button class="link light" id="so">Sign out</button>`)}${demoBanner()}
    <nav class="tabs" role="tablist">${TABS.filter(([k]) => ME.role === 'admin' || ['today', 'work'].includes(k)).map(([k, l]) => `<button role="tab" data-tab="${k}" aria-selected="${k === TAB}">${l}</button>`).join('')}</nav>
    <main class="pad wide" id="hr"></main>`;
  wireDemo(); $('#so').onclick = () => store.signOut();
  app.querySelectorAll('[data-tab]').forEach(b => b.onclick = () => { TAB = b.dataset.tab; try { sessionStorage.setItem('jayco-tab', TAB); } catch (e) {} hrShell(); });
  if (ME.role !== 'admin' && !['today', 'work'].includes(TAB)) TAB = 'today';
  ({ today: hrToday, work: hrWork, payroll: hrPayroll, workers: hrWorkers, settings: hrSettings })[TAB]();
}
const H = () => $('#hr');

/* ---------- Today ---------- */
async function hrToday(date = todayIST()) {
  H().innerHTML = `<div class="row wrap"><h1>Attendance</h1><input type="date" id="d" value="${date}"></div><p>Loading…</p>`;
  const [list, workers] = await Promise.all([store.dayList(date), store.listWorkers()]);
  const staff = workers.filter(w => w.role !== 'admin' && w.active !== false);
  const waitingReg = workers.filter(w => w.status === 'pending').length;
  const byEmp = Object.fromEntries(list.map(r => [r.empId, r]));
  const rows = staff.map(w => ({ w, r: byEmp[w.empId] })).sort((a, b) => (a.r ? 0 : 1) - (b.r ? 0 : 1) || String(a.w.empId).localeCompare(b.w.empId));
  let present = 0, late = 0, pending = 0;
  const trs = rows.map(({ w, r }) => {
    if (!r) return `<tr><td>${esc(w.empId)}</td><td>${esc(w.name)}</td><td colspan="6" class="muted">—</td><td><span class="pill bad">Absent</span></td><td></td></tr>`;
    present++;
    const d = RULES.dayResult(S, r.shift, minOfDayIST(r.inAt), r.outAt ? minOfDayIST(r.outAt) : null);
    if (d.isLate) late++; if (!r.work || !r.work.op) pending++;
    const st = !r.outAt ? '<span class="pill ok">On duty</span>' : d.credit === 1 ? '<span class="pill ok">Full day</span>' : d.credit === 0.5 ? '<span class="pill warn">Half day</span>' : '<span class="pill bad">Short day</span>';
    return `<tr><td>${esc(w.empId)}</td><td>${esc(w.name)}</td><td class="num">${r.shift}</td>
      <td class="num">${hhmm(r.inAt)}${d.isLate ? ` <span class="pill warn">+${d.lateMin}m</span>` : ''}</td><td class="num">${hhmm(r.outAt)}</td>
      <td class="num">${r.outAt ? RULES.fmtMin(d.workedMin) : '—'}</td><td class="num">${d.otMin ? RULES.fmtMin(d.otMin) : '—'}</td>
      <td>${r.work && r.work.op ? `${esc(r.work.part)} · ${esc(r.work.op)} · ${esc(r.work.qty)}` : '<span class="muted">Not written</span>'}</td><td>${st}</td>
      <td><button class="link" data-photo="${esc(r.id)}">Selfies</button>${ME.role === 'admin' ? ` <button class="link" data-edit="${esc(r.id)}">Edit</button>` : ''}</td></tr>`;
  }).join('');
  H().innerHTML = `<div class="row wrap"><h1>Attendance</h1><input type="date" id="d" value="${date}"></div>
    ${waitingReg && ME.role === 'admin' ? `<div class="pill warn">${waitingReg} new worker registration${waitingReg > 1 ? 's' : ''} waiting in Workers</div>` : ''}
    <div class="kpis"><div class="kpi"><b>${present}</b><span>Present of ${staff.length}</span></div><div class="kpi"><b>${late}</b><span>Late after ${S.graceMin} min grace</span></div>
      <div class="kpi"><b>${staff.length - present}</b><span>Absent</span></div><div class="kpi"><b>${pending}</b><span>Work not written</span></div></div>
    <div class="tbl"><table><thead><tr><th>ID</th><th>Name</th><th>Shift</th><th>In</th><th>Out</th><th>Worked</th><th>OT</th><th>Daily work</th><th>Status</th><th></th></tr></thead><tbody>${trs}</tbody></table></div>`;
  $('#d').onchange = (e) => hrToday(e.target.value);
  H().querySelectorAll('[data-photo]').forEach(b => b.onclick = () => showSelfies(b.dataset.photo, byEmpId(list, b.dataset.photo)));
  H().querySelectorAll('[data-edit]').forEach(b => b.onclick = () => editTimes(byEmpId(list, b.dataset.edit), () => hrToday(date)));
}
const byEmpId = (list, id) => list.find(r => r.id === id);

async function showSelfies(id, r) {
  const m = document.createElement('div'); m.className = 'modal'; m.innerHTML = `<div class="sheet wide-sheet"><p>Loading…</p></div>`;
  document.body.appendChild(m); m.onclick = (e) => { if (e.target === m) m.remove(); };
  const s = await store.getSelfies(id);
  const map = (lat, lng) => lat ? `<a href="https://www.google.com/maps?q=${lat},${lng}" target="_blank" rel="noopener">Map</a>` : '';
  $('.sheet', m).innerHTML = `<h2>${esc(r.name || r.empId)} · ${esc(r.date)}</h2><div class="selfies">
    <figure>${s.in ? `<img src="${s.in}" alt="Check-in selfie">` : '<div class="noimg">No photo</div>'}<figcaption>In ${hhmm(r.inAt)} · ${r.inDist ?? '—'} m ${map(r.inLat, r.inLng)}</figcaption></figure>
    <figure>${s.out ? `<img src="${s.out}" alt="Check-out selfie">` : '<div class="noimg">No photo</div>'}<figcaption>Out ${hhmm(r.outAt)} · ${r.outDist ?? '—'} m ${map(r.outLat, r.outLng)}</figcaption></figure></div>
    <button class="btn ghost" id="x">Close</button>`;
  $('#x', m).onclick = () => m.remove();
}

function editTimes(r, done) {
  const m = document.createElement('div'); m.className = 'modal';
  m.innerHTML = `<form class="sheet stack" id="ef"><h2>Correct times · ${esc(r.name || r.empId)} · ${esc(r.date)}</h2>
    <p class="note">Use only for genuine mistakes, such as a worker who forgot to check out. The change is recorded with your name.</p>
    <label>Shift<select id="es">${[1, 2, 3].map(n => `<option ${n === r.shift ? 'selected' : ''}>${n}</option>`).join('')}</select></label>
    <div class="row"><label class="grow">In<input type="time" id="ei" value="${hhmm(r.inAt)}" required></label><label class="grow">Out<input type="time" id="eo" value="${r.outAt ? hhmm(r.outAt) : ''}"></label></div>
    <label>Reason<input id="er" required placeholder="e.g. Forgot to check out, confirmed by supervisor"></label>
    <button class="btn">Save correction</button><button type="button" class="btn ghost" id="ec">Cancel</button></form>`;
  document.body.appendChild(m); $('#ec', m).onclick = () => m.remove();
  $('#ef', m).onsubmit = async (e) => {
    e.preventDefault();
    const mk = (v) => v ? new Date(`${r.date}T${v}:00+05:30`) : null;
    try {
      await store.editTimes(r.id, { shift: Number($('#es', m).value), inAt: mk($('#ei', m).value), outAt: mk($('#eo', m).value), editedBy: ME.name, editReason: $('#er', m).value, editedAt: new Date() });
      m.remove(); toast('Times corrected', 'ok'); done();
    } catch (err) { toast(err.message, 'bad'); }
  };
}

/* ---------- Work records ---------- */
async function hrWork(date = todayIST(), filter = 'pending') {
  H().innerHTML = `<h1>Work records</h1><p>Loading…</p>`;
  const list = (await store.dayList(date)).filter(r => r.work && r.work.op);
  const shown = list.filter(r => filter === 'all' || r.workStatus === filter).sort((a, b) => String(a.empId).localeCompare(b.empId));
  H().innerHTML = `<div class="row wrap"><h1>Work records</h1><div class="row"><input type="date" id="d" value="${date}">
    <select id="fl"><option value="pending">Waiting for approval</option><option value="approved">Approved</option><option value="rejected">Sent back</option><option value="all">All</option></select></div></div>
    ${shown.length ? '' : '<p class="muted">Nothing here for this day.</p>'}
    <div class="cards">${shown.map(r => `<div class="card"><div class="row"><b>${esc(r.name || r.empId)}</b><span class="pill ${r.workStatus === 'approved' ? 'ok' : r.workStatus === 'rejected' ? 'bad' : 'warn'}">${r.workStatus === 'approved' ? 'Approved' : r.workStatus === 'rejected' ? 'Sent back' : 'Waiting'}</span></div>
      <div>${esc(r.work.part)} · <b>${esc(r.work.op)}</b> · ${esc(r.work.qty)} pcs${r.work.machine ? ' · ' + esc(r.work.machine) : ''}</div>
      ${r.work.notes ? `<div class="note">${esc(r.work.notes)}</div>` : ''}
      <div class="row"><button class="btn small" data-ok="${esc(r.id)}">Approve</button><button class="btn small ghost" data-no="${esc(r.id)}">Send back</button></div></div>`).join('')}</div>`;
  $('#fl').value = filter;
  $('#d').onchange = (e) => hrWork(e.target.value, filter);
  $('#fl').onchange = (e) => hrWork(date, e.target.value);
  const act = (id, st) => store.setWorkStatus(id, st, ME.name).then(() => hrWork(date, filter)).catch(e => toast(e.message, 'bad'));
  H().querySelectorAll('[data-ok]').forEach(b => b.onclick = () => act(b.dataset.ok, 'approved'));
  H().querySelectorAll('[data-no]').forEach(b => b.onclick = () => act(b.dataset.no, 'rejected'));
}

/* ---------- Payroll ---------- */
async function hrPayroll(month = monthIST()) {
  H().innerHTML = `<h1>Payroll</h1><p>Loading…</p>`;
  const [list, workers, adv, loans] = await Promise.all([store.monthList(month), store.listWorkers(), store.advances(month), store.loans()]);
  const staff = workers.filter(w => w.role !== 'admin');
  const [y, mo] = month.split('-').map(Number);
  const rows = staff.map(w => {
    const days = list.filter(r => r.empId === w.empId && r.outAt).map(r => RULES.dayResult(S, r.shift, minOfDayIST(r.inAt), minOfDayIST(r.outAt)));
    const a = adv.filter(x => x.empId === w.empId).reduce((s, x) => s + Number(x.amount || 0), 0);
    const ln = loans.filter(x => x.empId === w.empId).reduce((s, x) => s + RULES.loanForMonth(x, month).due, 0);
    return { w, p: RULES.monthPay(S, days, Number(w.dailyWage || 0), a, w.pfEsi !== false, ln) };
  }).filter(x => x.p.daysPresent > 0 || x.p.advance > 0 || x.p.loan > 0 || x.w.active !== false);
  const nameOf = (id) => (workers.find(w => w.empId === id) || {}).name || '';
  const tot = rows.reduce((s, { p }) => ({ gross: s.gross + p.gross, net: s.net + p.net, ot: s.ot + p.otPay, pf: s.pf + p.pf, esi: s.esi + p.esi }), { gross: 0, net: 0, ot: 0, pf: 0, esi: 0 });
  H().innerHTML = `<div class="row wrap"><h1>Payroll</h1><div class="row"><input type="month" id="m" value="${month}"><button class="btn small" id="csv">Download CSV</button></div></div>
    <p class="note">${RULES.workingDays(y, mo - 1, S.weeklyOff)} working days, ${S.weeklyOff === 5 ? 'Friday' : 'Sunday'} off. Overtime: 1x under ${S.otThresholdH} h in the month, ${S.otRateHigh}x at ${S.otThresholdH} h or more. First ${S.lateFreeDays} late days free; each later late day costs 4 h, taken from overtime at 1x first.</p>
    <div class="kpis"><div class="kpi"><b>${inr(tot.gross)}</b><span>Gross</span></div><div class="kpi"><b>${inr(tot.ot)}</b><span>Overtime</span></div><div class="kpi"><b>${inr(tot.pf + tot.esi)}</b><span>PF + ESI</span></div><div class="kpi"><b>${inr(tot.net)}</b><span>Net to pay</span></div></div>
    <div class="tbl"><table><thead><tr><th>ID</th><th>Name</th><th>Wage/day</th><th>Days</th><th>Late</th><th>OT h</th><th>OT rate</th><th>Wages</th><th>OT pay</th><th>PF</th><th>ESI</th><th>Advance</th><th>Loan</th><th>Net</th></tr></thead>
    <tbody>${rows.map(({ w, p }) => `<tr><td>${esc(w.empId)}</td><td>${esc(w.name)}</td><td class="num">${inr(w.dailyWage)}</td><td class="num">${p.daysPresent}</td>
      <td class="num">${p.lateDays}${p.halfDays ? ` <span class="pill warn">${p.halfDays}×½</span>` : ''}</td><td class="num">${p.otH}${p.lateFromOtH ? ` <span class="note">(−${p.lateFromOtH})</span>` : ''}</td><td class="num">${p.mult}x</td>
      <td class="num">${inr(p.wages)}</td><td class="num">${inr(p.otPay)}</td><td class="num">${inr(p.pf)}</td><td class="num">${inr(p.esi)}</td><td class="num">${inr(p.advance)}</td><td class="num">${inr(p.loan)}</td><td class="num"><b>${inr(p.net)}</b></td></tr>`).join('')}</tbody></table></div>
    <h2>Salary advances, ${month}</h2>
    <form id="af" class="row wrap"><select id="ae">${staff.map(w => `<option value="${esc(w.empId)}">${esc(w.empId)} · ${esc(w.name)}</option>`).join('')}</select>
      <input id="aa" type="number" min="1" placeholder="Amount ₹" required><input id="an" placeholder="Note"><button class="btn small">Add advance</button></form>
    <ul class="list">${adv.map(a => `<li>${esc(a.empId)} · ${inr(a.amount)} ${a.note ? '· ' + esc(a.note) : ''} <button class="link" data-del="${esc(a.id)}">Remove</button></li>`).join('')}</ul>
    <h2>Loans</h2>
    <p class="note">The monthly instalment is cut from pay every month from the start month until the loan is repaid. Balances below are after ${month}'s instalment.</p>
    <form id="lf" class="row wrap"><select id="le">${staff.map(w => `<option value="${esc(w.empId)}">${esc(w.empId)} · ${esc(w.name)}</option>`).join('')}</select>
      <input id="la" type="number" min="1" placeholder="Loan amount ₹" required><input id="li" type="number" min="1" placeholder="Monthly instalment ₹" required>
      <label class="row">Start <input id="ls" type="month" value="${month}" required></label><input id="ln" placeholder="Note"><button class="btn small">Add loan</button></form>
    ${loans.length ? `<div class="tbl"><table><thead><tr><th>ID</th><th>Name</th><th>Loan</th><th>Instalment</th><th>Start</th><th>This month</th><th>Repaid</th><th>Balance</th><th>Months left</th><th></th></tr></thead><tbody>
      ${loans.sort((a, b) => String(a.empId).localeCompare(b.empId) || String(a.startMonth).localeCompare(b.startMonth)).map(l => { const r = RULES.loanForMonth(l, month); return `<tr>
        <td>${esc(l.empId)}</td><td>${esc(nameOf(l.empId))}${l.note ? ` <span class="note">${esc(l.note)}</span>` : ''}</td><td class="num">${inr(l.amount)}</td><td class="num">${inr(l.instalment)}</td><td>${esc(l.startMonth)}</td>
        <td class="num">${inr(r.due)}</td><td class="num">${inr(r.paidBefore + r.due)}</td><td class="num"><b>${inr(r.balance)}</b></td>
        <td class="num">${r.settled ? `<span class="pill">Settled ${esc(l.settledMonth)}</span>` : r.balance ? r.monthsLeft : '<span class="pill ok">Repaid</span>'}</td>
        <td>${!r.settled && r.balance ? `<button class="link" data-settle="${esc(l.id)}">Settle</button> ` : ''}<button class="link" data-ldel="${esc(l.id)}">Remove</button></td></tr>`; }).join('')}
    </tbody></table></div>` : '<p class="note">No loans yet.</p>'}`;
  $('#m').onchange = (e) => hrPayroll(e.target.value);
  $('#af').onsubmit = async (e) => { e.preventDefault(); await store.addAdvance({ empId: $('#ae').value, month, amount: Number($('#aa').value), note: $('#an').value, by: ME.name }); hrPayroll(month); };
  H().querySelectorAll('[data-del]').forEach(b => b.onclick = async () => { await store.deleteAdvance(b.dataset.del); hrPayroll(month); });
  $('#lf').onsubmit = async (e) => {
    e.preventDefault();
    const amount = Number($('#la').value), instalment = Number($('#li').value);
    if (instalment > amount) return toast('The instalment cannot be more than the loan.', 'bad');
    await store.addLoan({ empId: $('#le').value, amount, instalment, startMonth: $('#ls').value, note: $('#ln').value, by: ME.name });
    toast('Loan added', 'ok'); hrPayroll(month);
  };
  H().querySelectorAll('[data-settle]').forEach(b => b.onclick = async () => {
    const l = loans.find(x => x.id === b.dataset.settle);
    const owed = RULES.loanForMonth(l, month).paidBefore;
    if (!confirm(`Mark this loan as settled in ${month}? No more instalments will be cut from ${month} on. Repaid by instalments before ${month}: ${inr(owed)}; take the remaining ${inr(Number(l.amount) - owed)} in cash.`)) return;
    await store.settleLoan(l.id, month); hrPayroll(month);
  });
  H().querySelectorAll('[data-ldel]').forEach(b => b.onclick = async () => {
    if (!confirm('Remove this loan? Its instalments will disappear from every month\'s payroll.')) return;
    await store.deleteLoan(b.dataset.ldel); hrPayroll(month);
  });
  $('#csv').onclick = () => {
    const head = ['Emp ID', 'Name', 'Daily wage', 'Days present', 'Late days', 'Late half days', 'OT hours', 'OT hours used for late', 'OT rate', 'Wages', 'OT pay', 'Gross', 'PF', 'ESI', 'Advance', 'Loan instalment', 'Net'];
    const lines = rows.map(({ w, p }) => [w.empId, w.name, w.dailyWage, p.daysPresent, p.lateDays, p.halfDays, p.otH, p.lateFromOtH, p.mult, p.wages, p.otPay, p.gross, p.pf, p.esi, p.advance, p.loan, p.net]);
    const csv = [head, ...lines].map(r => r.map(v => `"${String(v ?? '').replace(/"/g, '""')}"`).join(',')).join('\n');
    const a = document.createElement('a'); a.href = URL.createObjectURL(new Blob(['﻿' + csv], { type: 'text/csv' })); a.download = `JAYCO-payroll-${month}.csv`; a.click();
  };
}

/* ---------- Workers ---------- */
async function hrWorkers() {
  const [allW, resets, seen] = await Promise.all([store.listWorkers(), store.pinResets().catch(() => []), store.appSeen().catch(() => ({}))]);
  const all = allW.filter(w => w.role !== 'admin').sort((a, b) => String(a.empId).localeCompare(b.empId));
  const ownerOf = (r) => all.find(w => w.status !== 'pending' && w.status !== 'rejected' && w.status !== 'removed' && (String(w.phone) === r.mobile || String(w.empId) === r.mobile));
  const pending = all.filter(w => w.status === 'pending');
  const removed = all.filter(w => w.status === 'removed');
  const workers = all.filter(w => w.status !== 'pending' && w.status !== 'rejected' && w.status !== 'removed');
  linkOldLogins(workers);
  const seenCell = (w) => { const d = seen[w.empId]; return d ? `<span class="pill ok" title="Last opened ${esc(d.toLocaleString('en-IN'))}">${esc(d.toLocaleDateString('en-IN', { day: 'numeric', month: 'short' }))}</span>` : '<span class="pill warn" title="This phone has not opened the app since reminders started">Not yet</span>'; };
  H().innerHTML = `<div class="row wrap"><h1>Workers</h1><span class="note">${workers.filter(w => w.active !== false).length} active</span><button class="btn small" id="addbtn" style="margin-left:auto">+ Add employee</button></div>
    ${pending.length ? `<div class="card stack"><h2>New registrations waiting (${pending.length})</h2>
      <p class="note">Workers registered themselves in the app. Check the photo and details, set the Employee ID and daily wage, then approve. Their login stays their mobile number and PIN.</p>
      <div class="cards">${pending.map(w => `<form class="card stack" data-approve="${esc(w.uid)}"><div class="row" style="justify-content:flex-start">
        <div class="avatar">${w.photo ? `<img src="${w.photo}" alt="">` : ''}</div><div><b>${esc(w.name)}</b><div class="note">${esc(w.phone)}${w.dept ? ' · ' + esc(w.dept) : ''}</div></div></div>
        <div class="formgrid"><label>Employee ID<input name="empId" value="${esc(w.empId)}" required pattern="[A-Za-z0-9]+"></label>
        <label>Daily wage ₹<input name="wage" type="number" min="1" required></label>
        <label>Role<select name="role"><option value="worker">Worker</option><option value="supervisor">Supervisor</option></select></label>
        <label>Shift (worker chose)<select name="shift">${[1, 2, 3].map(n => `<option value="${n}" ${Number(w.shift || 1) === n ? 'selected' : ''}>Shift ${n} (${S.shifts[n].start}–${S.shifts[n].end})</option>`).join('')}</select></label></div>
        ${w.rulesAccepted ? '<div class="note">✓ Accepted company rules at registration</div>' : ''}
        <div class="row" style="justify-content:flex-start"><button class="btn small">Approve</button><button type="button" class="btn small ghost" data-reject="${esc(w.uid)}">Reject</button></div></form>`).join('')}</div></div>` : ''}
    ${resets.length ? `<div class="card stack"><h2>Forgot PIN requests (${resets.length})</h2>
      <p class="note">A worker asked for a new PIN. Compare the new selfie with their profile photo, call their mobile to confirm, then approve. Their attendance, pay and loans stay as they are.</p>
      <div class="cards">${resets.map(r => { const w = ownerOf(r); return `<div class="card stack"><div class="row" style="justify-content:flex-start">
        <div class="avatar">${r.photo ? `<img src="${r.photo}" alt="New selfie">` : ''}</div><div class="avatar">${w && w.photo ? `<img src="${w.photo}" alt="Profile photo">` : ''}</div>
        <div><b>${w ? esc(w.name) : 'No worker with this mobile'}</b><div class="note">${esc(r.mobile)}${w ? ' · ID ' + esc(w.empId) : ''}</div><div class="note">Left: new selfie · Right: profile</div></div></div>
        <div class="row" style="justify-content:flex-start">${w ? `<button class="btn small" data-rs-ok="${esc(r.uid)}">Approve new PIN</button>` : ''}<button class="btn small ghost" data-rs-no="${esc(r.uid)}">Reject</button></div></div>`; }).join('')}</div></div>` : ''}
    <form id="nf" class="card stack" hidden><h2>Add employee</h2>
      <p class="note">The worker signs in with their mobile number and the PIN you set here. They can change the PIN later in the app.</p><div class="formgrid">
      <label>Mobile number<input id="n-ph" inputmode="tel" required pattern="(\+?91)?0?[6-9][0-9]{9}" title="10-digit mobile number"></label><label>Name<input id="n-name" required></label>
      <label>Employee ID (optional)<input id="n-id" pattern="[A-Za-z0-9]+" title="Letters and numbers only" placeholder="Empty = mobile number"></label>
      <label>Department<input id="n-dept"></label>
      <label>Daily wage ₹<input id="n-wage" type="number" min="0" required></label>
      <label>Role<select id="n-role"><option value="worker">Worker</option><option value="supervisor">Supervisor (approves work)</option></select></label>
      <label>Shift<select id="n-shift">${[1, 2, 3].map(n => `<option value="${n}" ${Number(1) === n ? 'selected' : ''}>Shift ${n} (${S.shifts[n].start}–${S.shifts[n].end})</option>`).join('')}</select></label>
      <label>Starting PIN (6 digits)<input id="n-pin" inputmode="numeric" pattern="[0-9]{6}" required></label></div>
      <div class="row" style="justify-content:flex-start"><button class="btn small">Add employee</button><button type="button" class="btn small ghost" id="n-cancel">Cancel</button></div></form>
    <div class="tbl"><table><thead><tr><th>ID</th><th>Name</th><th>Dept</th><th>Mobile</th><th>Wage/day</th><th>Shift</th><th>Role</th><th>PF/ESI</th><th>Active</th><th>App</th><th></th></tr></thead><tbody>
    ${workers.map(w => `<tr data-uid="${esc(w.uid)}"><td>${esc(w.empId)}</td><td><input class="in" data-f="name" value="${esc(w.name)}"></td><td><input class="in" data-f="dept" value="${esc(w.dept)}"></td>
      <td><input class="in" data-f="phone" value="${esc(w.phone)}"></td><td><input class="in num" data-f="dailyWage" type="number" value="${esc(w.dailyWage)}"></td>
      <td><select class="in" data-f="shift">${[1, 2, 3].map(n => `<option value="${n}" ${Number(w.shift || 0) === n ? 'selected' : ''}>${n}</option>`).join('')}${w.shift ? '' : '<option value="" selected>—</option>'}</select></td>
      <td><select class="in" data-f="role"><option value="worker" ${w.role === 'worker' ? 'selected' : ''}>Worker</option><option value="supervisor" ${w.role === 'supervisor' ? 'selected' : ''}>Supervisor</option></select></td>
      <td><input type="checkbox" data-f="pfEsi" ${w.pfEsi !== false ? 'checked' : ''}></td><td><input type="checkbox" data-f="active" ${w.active !== false ? 'checked' : ''}></td>
      <td>${seenCell(w)}</td><td class="nowrap"><button class="link" data-save>Save</button> · <button class="link" data-pin>New PIN</button> · <button class="link" data-remove>Remove</button></td></tr>`).join('')}</tbody></table></div>
    <p class="note">Worker can't sign in? Tap <b>New PIN</b>, set a 6-digit PIN and tell them: sign in with your mobile number and this PIN. "App" shows the last day their phone opened the app.</p>
    ${removed.length ? `<details class="card stack"><summary><b>Removed employees (${removed.length})</b> <span class="note">Their attendance and pay history is kept.</span></summary>
      <div class="tbl"><table><thead><tr><th>ID</th><th>Name</th><th>Mobile</th><th>Removed by</th><th></th></tr></thead><tbody>
      ${removed.map(w => `<tr data-uid="${esc(w.uid)}"><td>${esc(w.empId)}</td><td>${esc(w.name)}</td><td>${esc(w.phone)}</td><td>${esc(w.removedBy || '')}</td>
        <td class="nowrap"><button class="link" data-restore>Restore</button> · <button class="link" data-delete>Delete forever</button></td></tr>`).join('')}</tbody></table></div></details>` : ''}`;
  const byUid = (el) => all.find(w => w.uid === el.closest('tr').dataset.uid);
  $('#addbtn').onclick = () => { $('#nf').hidden = false; $('#nf').scrollIntoView({ behavior: 'smooth' }); $('#n-ph').focus(); };
  $('#n-cancel').onclick = () => { $('#nf').hidden = true; };
  H().querySelectorAll('[data-pin]').forEach(b => b.onclick = () => newPinSheet(byUid(b)));
  H().querySelectorAll('[data-remove]').forEach(b => b.onclick = async () => {
    const w = byUid(b);
    if (!confirm(`Remove ${w.name} (${w.empId})?\n\nThey can no longer sign in. Their attendance, pay and loan history stays, and you can restore them later from "Removed employees".`)) return;
    try { await store.removeWorker(w.uid, ME.name); toast(`${w.name} removed`, 'ok'); hrWorkers(); } catch (err) { toast(err.message, 'bad'); }
  });
  H().querySelectorAll('[data-restore]').forEach(b => b.onclick = async () => {
    const w = byUid(b);
    if (workers.some(x => String(x.empId).toLowerCase() === String(w.empId).toLowerCase())) return toast('Another active employee already uses this Employee ID.', 'bad');
    try { await store.restoreWorker(w.uid); toast(`${w.name} restored. They sign in with their old PIN.`, 'ok'); hrWorkers(); } catch (err) { toast(err.message, 'bad'); }
  });
  H().querySelectorAll('[data-delete]').forEach(b => b.onclick = async () => {
    const w = byUid(b);
    if (!confirm(`Delete ${w.name} (${w.empId}) forever?\n\nTheir profile is erased and cannot be restored. Past attendance records stay, but they will no longer appear in Payroll. Use this only for duplicates or wrong entries.`)) return;
    try { await store.deleteWorker(w.uid); toast(`${w.name} deleted`, 'ok'); hrWorkers(); } catch (err) { toast(err.message, 'bad'); }
  });
  H().querySelectorAll('[data-rs-ok]').forEach(b => b.onclick = async () => {
    const r = resets.find(x => x.uid === b.dataset.rsOk), w = ownerOf(r);
    if (!confirm(`Give ${w.name} (${r.mobile}) the new PIN they chose? Their old PIN stops working.`)) return;
    try { await store.approvePinReset(r, w); toast('Approved. The worker can sign in with the new PIN.', 'ok'); hrWorkers(); } catch (err) { toast(err.message, 'bad'); }
  });
  H().querySelectorAll('[data-rs-no]').forEach(b => b.onclick = async () => {
    if (!confirm('Reject this PIN request?')) return;
    try { await store.rejectPinReset(b.dataset.rsNo); toast('Request rejected', 'ok'); hrWorkers(); } catch (err) { toast(err.message, 'bad'); }
  });
  H().querySelectorAll('[data-approve]').forEach(f => f.onsubmit = async (e) => {
    e.preventDefault();
    const empId = f.empId.value.trim();
    if (all.some(x => x.uid !== f.dataset.approve && String(x.empId).toLowerCase() === empId.toLowerCase() && x.status !== 'rejected')) return toast('That Employee ID is already in use.', 'bad');
    const w = all.find(x => x.uid === f.dataset.approve);
    try {
      await store.saveWorker(f.dataset.approve, { empId, dailyWage: Number(f.wage.value), role: f.role.value, shift: Number(f.shift.value), active: true, status: 'approved', pfEsi: true, approvedBy: ME.name });
      if (w && w.phone && empId.toLowerCase() !== String(w.phone).toLowerCase()) await store.linkLogin(empId, empEmail(w.phone)).catch(() => {});
      toast('Approved. The worker can now sign in with their mobile number and PIN.', 'ok'); hrWorkers();
    }
    catch (err) { toast(err.message, 'bad'); }
  });
  H().querySelectorAll('[data-reject]').forEach(b => b.onclick = async () => {
    try { await store.saveWorker(b.dataset.reject, { status: 'rejected', active: false, approvedBy: ME.name }); toast('Registration rejected', 'ok'); hrWorkers(); } catch (err) { toast(err.message, 'bad'); }
  });
  $('#nf').onsubmit = async (e) => {
    e.preventDefault();
    const phone = normId($('#n-ph').value);
    const w = { empId: $('#n-id').value.trim() || phone, name: $('#n-name').value.trim(), dept: $('#n-dept').value.trim(), phone, dailyWage: Number($('#n-wage').value), role: $('#n-role').value, shift: Number($('#n-shift').value), pfEsi: true, addedBy: ME.name };
    const clash = all.find(x => x.status !== 'rejected' && (String(x.empId).toLowerCase() === w.empId.toLowerCase() || (x.phone && String(x.phone) === phone)));
    if (clash) return toast(clash.status === 'removed' ? `${clash.name} (${clash.empId}) is in Removed employees. Restore them instead.` : clash.status === 'pending' ? `${clash.name} already registered with this number. Approve them under "New registrations waiting".` : `${clash.name} (${clash.empId}) already uses this Employee ID or mobile number.`, 'bad');
    const b = e.submitter; if (b) b.disabled = true;
    try { await store.createWorker(w, $('#n-pin').value); toast(`${w.name} added. They sign in with mobile ${phone} and the PIN you set.`, 'ok'); hrWorkers(); }
    catch (err) { if (b) b.disabled = false; toast(err.code === 'auth/weak-password' ? 'PIN must be 6 digits.' : err.message, 'bad'); }
  };
  H().querySelectorAll('[data-save]').forEach(b => b.onclick = async () => {
    const tr = b.closest('tr'), data = {};
    tr.querySelectorAll('[data-f]').forEach(i => { data[i.dataset.f] = i.type === 'checkbox' ? i.checked : (i.dataset.f === 'dailyWage' || i.dataset.f === 'shift') ? Number(i.value) : i.value.trim(); });
    try { await store.saveWorker(tr.dataset.uid, data); toast('Saved', 'ok'); } catch (err) { toast(err.message, 'bad'); }
  });
}

/* HR sets a new PIN for a worker who cannot sign in. */
function newPinSheet(w) {
  const m = document.createElement('div'); m.className = 'modal';
  m.innerHTML = `<form class="sheet stack" id="pf"><h2>New PIN · ${esc(w.name)}</h2>
    <p class="note">Their old PIN stops working. Attendance, pay and loans stay as they are. Tell the worker to sign in with mobile <b>${esc(w.phone || w.empId)}</b> and this PIN.</p>
    <label>New 6-digit PIN<input id="pp" inputmode="numeric" pattern="[0-9]{6}" maxlength="6" required autocomplete="off"></label>
    <button class="btn" id="pgo">Set new PIN</button><button type="button" class="btn ghost" id="pc">Cancel</button></form>`;
  document.body.appendChild(m); $('#pc', m).onclick = () => m.remove(); $('#pp', m).focus();
  $('#pf', m).onsubmit = async (e) => {
    e.preventDefault(); $('#pgo', m).disabled = true;
    try { await store.setWorkerPin(w, $('#pp', m).value); m.remove(); toast(`New PIN set for ${w.name}.`, 'ok'); hrWorkers(); }
    catch (err) { $('#pgo', m).disabled = false; toast(err.message, 'bad'); }
  };
}

/* One-time fix for workers whose Employee ID and mobile differ: make both work at sign-in. */
let LINKED = false;
async function linkOldLogins(workers) {
  if (LINKED || store.mode !== 'firebase') return; LINKED = true;
  for (const w of workers) {
    const id = normId(w.empId), ph = normId(w.phone);
    if (!ph || !id || id === ph || w.pinResetAt) continue;
    const [other, own] = w.registeredAt ? [id, ph] : [ph, id];   // self-registered: login is the mobile; HR-added: login is the ID
    if (!(await store.getLogin(other))) await store.linkLogin(other, empEmail(own)).catch(() => {});
  }
}

/* ---------- Settings ---------- */
function hrSettings() {
  const f = S.factory;
  H().innerHTML = `<h1>Settings</h1><form id="sf" class="stack narrowish">
    <div class="card stack"><h2>Weekly off</h2><div class="switch" role="group" aria-label="Weekly off">
      <button type="button" data-off="0" aria-pressed="${S.weeklyOff === 0}">Sunday</button><button type="button" data-off="5" aria-pressed="${S.weeklyOff === 5}">Friday</button></div>
      <p class="note">Festival holidays are unpaid.</p></div>
    <div class="card stack"><h2>Factory location</h2><div class="formgrid">
      <label>Latitude<input id="s-lat" type="number" step="any" value="${f.lat}"></label><label>Longitude<input id="s-lng" type="number" step="any" value="${f.lng}"></label>
      <label>Radius (m)<input id="s-rad" type="number" min="10" value="${f.radius}"></label><label>Weakest GPS allowed (± m)<input id="s-acc" type="number" min="10" value="${S.maxAccuracy || 60}"></label></div>
      <a href="https://www.google.com/maps?q=${f.lat},${f.lng}" target="_blank" rel="noopener">Open pin in Google Maps</a></div>
    <div class="card stack"><h2>Late and overtime</h2><div class="formgrid">
      <label>Late grace (minutes)<input id="s-grace" type="number" min="0" value="${S.graceMin}"></label>
      <label>Free late days per month<input id="s-free" type="number" min="0" value="${S.lateFreeDays}"></label>
      <label>OT hours for higher rate<input id="s-ot" type="number" min="0" value="${S.otThresholdH}"></label>
      <label>Higher OT rate<input id="s-otr" type="number" step="0.25" min="1" value="${S.otRateHigh}"></label></div></div>
    <div class="card stack"><h2>Shift times</h2><div class="formgrid">${[1, 2, 3].map(n => `<label>Shift ${n} start<input type="time" id="s${n}a" value="${S.shifts[n].start}"></label><label>Shift ${n} end<input type="time" id="s${n}b" value="${S.shifts[n].end}"></label>`).join('')}</div>
      <p class="note">Lunch ${S.lunch.start}–${S.lunch.end} for every shift.</p></div>
    <button class="btn">Save settings</button></form>
    ${store.mode === 'firebase' ? `<div class="card stack"><h2>Selfie storage</h2><p class="note">Selfies older than ${S.selfieKeepDays} days can be deleted to stay inside the free plan. Attendance records are kept.</p><button class="btn ghost small" id="purge">Delete old selfies</button></div>` : ''}`;
  let off = S.weeklyOff;
  H().querySelectorAll('[data-off]').forEach(b => b.onclick = () => { off = +b.dataset.off; H().querySelectorAll('[data-off]').forEach(x => x.setAttribute('aria-pressed', +x.dataset.off === off)); });
  $('#sf').onsubmit = async (e) => {
    e.preventDefault(); const v = (id) => Number($(id).value);
    const next = { weeklyOff: off, factory: { lat: v('#s-lat'), lng: v('#s-lng'), radius: v('#s-rad') }, maxAccuracy: v('#s-acc'), graceMin: v('#s-grace'), lateFreeDays: v('#s-free'), otThresholdH: v('#s-ot'), otRateHigh: v('#s-otr'),
      shifts: Object.fromEntries([1, 2, 3].map(n => [n, { start: $(`#s${n}a`).value, end: $(`#s${n}b`).value }])) };
    try { await store.saveSettings(next); S = { ...S, ...next }; toast('Settings saved', 'ok'); } catch (err) { toast(err.message, 'bad'); }
  };
  const p = $('#purge'); if (p) p.onclick = async () => {
    const cut = new Date(Date.now() - S.selfieKeepDays * 864e5).toISOString().slice(0, 10);
    try { const n = await store.purgeSelfies(cut); toast(`${n} old selfie records deleted`, 'ok'); } catch (err) { toast(err.message, 'bad'); }
  };
}
