/* HR panel: Today, Calendar, Work records, Payroll, Workers, Settings. English only. */
const TABS = [['today', 'Today', 'today'], ['calendar', 'Calendar', 'calendar'], ['work', 'Work records', 'clipboard'], ['payroll', 'Payroll', 'rupee'], ['workers', 'Workers', 'users'], ['settings', 'Settings', 'gear']];
const STAFF_TABS = ['today', 'calendar', 'work'];   // supervisors see these; admin sees all
let TAB = 'today';
try { TAB = sessionStorage.getItem('jayco-tab') || 'today'; } catch (e) {}

/* Extra sharp SVG icons for the HR panel (same 24px line style as the worker app). */
Object.assign(ICONS, {
  today: '<rect x="3" y="4" width="18" height="17" rx="3"/><path d="M3 9h18M8 2.5v3M16 2.5v3"/><path d="M8.5 14.5l2.3 2.3 4.7-4.6"/>',
  users: '<circle cx="9" cy="8" r="3.5"/><path d="M2.5 20c1-3.6 3.5-5.5 6.5-5.5s5.5 1.9 6.5 5.5"/><path d="M15.5 4.8a3.3 3.3 0 0 1 0 6.4M18 14.8c1.8.8 3 2.6 3.5 5.2"/>',
  gear: '<circle cx="12" cy="12" r="3.2"/><path d="M12 2.8l1.6 2.4 2.8-.7.7 2.8 2.4 1.6-1.2 2.6 1.2 2.6-2.4 1.6-.7 2.8-2.8-.7L12 21.2l-1.6-2.4-2.8.7-.7-2.8-2.4-1.6L5.7 12 4.5 9.4l2.4-1.6.7-2.8 2.8.7z"/>',
  edit: '<path d="M4 20h4L19 9a2.8 2.8 0 0 0-4-4L4 16z"/><path d="M13.5 6.5l4 4"/>',
  image: '<rect x="3" y="4" width="18" height="16" rx="3"/><circle cx="9" cy="10" r="2"/><path d="M21 16l-5-5-9 9"/>',
  chevL: '<path d="M15 5l-7 7 7 7"/>', chevR: '<path d="M9 5l7 7-7 7"/>',
  alert: '<path d="M12 3l9.5 17h-19z"/><path d="M12 10v4.5"/><circle cx="12" cy="17.3" r=".6" fill="currentColor"/>',
  xcirc: '<circle cx="12" cy="12" r="9"/><path d="M9 9l6 6M15 9l-6 6"/>',
  print: '<path d="M7 9V3h10v6"/><rect x="3" y="9" width="18" height="8" rx="2"/><path d="M7 14h10v7H7z"/>',
  grid: '<rect x="3" y="3" width="7.5" height="7.5" rx="1.5"/><rect x="13.5" y="3" width="7.5" height="7.5" rx="1.5"/><rect x="3" y="13.5" width="7.5" height="7.5" rx="1.5"/><rect x="13.5" y="13.5" width="7.5" height="7.5" rx="1.5"/>',
  map: '<path d="M9 4L3 6.5v13.5l6-2.5 6 2.5 6-2.5V4l-6 2.5z"/><path d="M9 4v13.5M15 6.5V20"/>'
});
const initials = (n) => String(n || '?').replace(/[^\p{L}\s]/gu, '').trim().split(/\s+/).slice(0, 2).map(x => x[0] || '').join('').toUpperCase() || '?';
const avatarChip = (w) => `<span class="ava">${w && w.photo ? `<img src="${w.photo}" alt="">` : esc(initials(w && w.name))}</span>`;
const longDate = (date) => new Date(date + 'T12:00:00Z').toLocaleDateString('en-IN', { weekday: 'long', day: 'numeric', month: 'long', year: 'numeric', timeZone: 'UTC' });
const pageHead = (title, kicker, controls = '') => `<div class="phead"><div><div class="kicker">${kicker}</div><h1>${title}</h1></div><div class="phead-ctl">${controls}</div></div>`;

function hrLogin() {
  document.body.className = 'hx hx-out';
  app.innerHTML = `${demoBanner()}<div class="hx-login"><div class="hx-login-card"><div class="hx-login-top"><img src="icons/logo-white.png" alt="JAYCO" class="bar-logo"><span>Attendance · HR</span></div><main class="pad narrow"><h1>HR / owner sign in</h1>
    <form id="f" class="stack">
      <label>Email<input id="em" type="email" autocomplete="username" required></label>
      <label>Password<input id="pw" type="password" autocomplete="current-password" minlength="6" required></label>
      <button class="btn" id="go">Sign in</button>
      ${store.mode === 'demo' ? '<p class="note">Demo: hr@demo, password demo123</p>' : '<button type="button" class="btn ghost" id="owner">First time: create owner account</button>'}
    </form><p class="note center"><button type="button" class="link" id="forgot">Forgot password?</button> · <a href="#">Worker sign in</a></p></main></div></div>`;
  wireDemo();
  $('#f').onsubmit = async (e) => {
    e.preventDefault(); const b = $('#go'); b.disabled = true;
    try { await store.signInAdmin($('#em').value.trim(), $('#pw').value); } catch (err) { b.disabled = false; toast('Wrong email or password', 'bad'); }
  };
  $('#forgot').onclick = async () => {
    const em = $('#em').value.trim();
    if (!em) return toast('Type your email above first, then tap Forgot password.', 'bad');
    try { await store.resetPassword(em); toast('Password reset email sent. Check your inbox (and Spam).', 'ok'); }
    catch (err) { toast(err.code === 'auth/invalid-email' ? 'That email address is not valid.' : err.code === 'auth/too-many-requests' ? 'Too many tries. Wait a few minutes and try again.' : (err.message || 'Could not send the email.'), 'bad'); }
  };
  const o = $('#owner'); if (o) o.onclick = async () => {
    const em = $('#em').value.trim(), pw = $('#pw').value;
    if (!em || pw.length < 6) return toast('Enter your owner email and a password of 6 or more characters first.', 'bad');
    try { await store.createOwner(em, pw, 'Owner'); toast('Owner account created', 'ok'); }
    catch (err) { toast(err.code === 'permission-denied' ? 'Only the owner email set up for JAYCO can create this account.' : err.message, 'bad'); }
  };
}

function hrShell() {
  document.body.className = 'hx';
  if (ME.role !== 'admin' && !STAFF_TABS.includes(TAB)) TAB = 'today';
  const tabs = TABS.filter(([k]) => ME.role === 'admin' || STAFF_TABS.includes(k));
  app.innerHTML = `<div class="hx-shell"><aside class="hx-side">
      <div class="hx-brand"><img src="icons/logo-white.png" alt="JAYCO" class="hx-logo"><span>Attendance · HR</span></div>
      <nav class="hx-nav" role="tablist" aria-label="HR menu">${tabs.map(([k, l, i]) => `<button role="tab" data-tab="${k}" aria-selected="${k === TAB}">${ic(i)}<span>${l}</span></button>`).join('')}</nav>
      <div class="hx-me"><span class="ava">${esc(initials(ME.name))}</span><div class="hx-me-t"><b>${esc(ME.name)}</b><span>${ME.role === 'admin' ? 'Owner · admin' : esc(ME.role)}</span></div>
        <button class="hx-so" id="so" title="Sign out" aria-label="Sign out">${ic('logout')}</button></div>
    </aside><div class="hx-main">${demoBanner()}<main class="pad wide" id="hr"></main></div></div>`;
  wireDemo(); $('#so').onclick = () => store.signOut();
  app.querySelectorAll('[data-tab]').forEach(b => b.onclick = () => { TAB = b.dataset.tab; try { sessionStorage.setItem('jayco-tab', TAB); } catch (e) {} hrShell(); window.scrollTo(0, 0); });
  ({ today: hrToday, calendar: hrCalendar, work: hrWork, payroll: hrPayroll, workers: hrWorkers, settings: hrSettings })[TAB]();
}
const H = () => $('#hr');

/* ---------- Today ---------- */
async function hrToday(date = todayIST()) {
  H().innerHTML = `${pageHead('Attendance', esc(longDate(date)), `<input type="date" id="d" value="${date}">`)}<div class="skel"></div>`;
  const [list, workers] = await Promise.all([store.dayList(date), store.listWorkers()]);
  const staff = workers.filter(w => w.role !== 'admin' && w.active !== false);
  const waitingReg = workers.filter(w => w.status === 'pending').length;
  const byEmp = Object.fromEntries(list.map(r => [r.empId, r]));
  const rows = staff.map(w => ({ w, r: byEmp[w.empId] })).sort((a, b) => (a.r ? 0 : 1) - (b.r ? 0 : 1) || String(a.w.empId).localeCompare(b.w.empId));
  let present = 0, late = 0, pending = 0;
  const trs = rows.map(({ w, r }) => {
    if (!r) return `<tr class="is-abs"><td class="num muted">${esc(w.empId)}</td><td><div class="who">${avatarChip(w)}<span>${esc(w.name)}</span></div></td><td colspan="6" class="muted">—</td><td><span class="pill bad">Absent</span></td><td><button class="ibtn" data-cal="${esc(w.empId)}" title="Month calendar" aria-label="Month calendar">${ic('calendar')}</button></td></tr>`;
    present++;
    const d = RULES.dayResult(S, r.shift, minOfDayIST(r.inAt), r.outAt ? minOfDayIST(r.outAt) : null);
    if (d.isLate) late++; if (!r.work || !r.work.op) pending++;
    const st = !r.outAt ? '<span class="pill ok">On duty</span>' : d.credit === 1 ? '<span class="pill ok">Full day</span>' : d.credit === 0.5 ? '<span class="pill warn">Half day</span>' : '<span class="pill bad">Short day</span>';
    return `<tr><td class="num muted">${esc(w.empId)}</td><td><div class="who">${avatarChip(w)}<span>${esc(w.name)}</span></div></td><td class="num"><span class="shiftno">${r.shift}</span></td>
      <td class="num">${hhmm(r.inAt)}${d.isLate ? ` <span class="pill warn">+${d.lateMin}m</span>` : ''}</td><td class="num">${hhmm(r.outAt)}</td>
      <td class="num">${r.outAt ? RULES.fmtMin(d.workedMin) : '—'}</td><td class="num">${d.otMin ? RULES.fmtMin(d.otMin) : '—'}</td>
      <td>${r.work && r.work.op ? `${esc(r.work.part)} · ${esc(r.work.op)} · ${esc(r.work.qty)}` : '<span class="muted">Not written</span>'}</td><td>${st}</td>
      <td class="nowrap"><button class="ibtn" data-photo="${esc(r.id)}" title="Selfies" aria-label="Selfies">${ic('camera')}</button>${ME.role === 'admin' ? `<button class="ibtn" data-edit="${esc(r.id)}" title="Edit times" aria-label="Edit times">${ic('edit')}</button>` : ''}<button class="ibtn" data-cal="${esc(w.empId)}" title="Month calendar" aria-label="Month calendar">${ic('calendar')}</button></td></tr>`;
  }).join('');
  const pct = staff.length ? Math.round(present * 100 / staff.length) : 0;
  const kpi = (icon, tone, val, label, extra = '') => `<div class="kpi tone-${tone}"><span class="kpi-ic">${ic(icon)}</span><b>${val}</b><span>${label}</span>${extra}</div>`;
  H().innerHTML = `${pageHead('Attendance', esc(longDate(date)), `<input type="date" id="d" value="${date}">`)}
    ${waitingReg && ME.role === 'admin' ? `<div class="banner">${ic('users')}<span><b>${waitingReg} new worker registration${waitingReg > 1 ? 's' : ''}</b> waiting for approval in Workers.</span></div>` : ''}
    <div class="kpis">${kpi('check', 'ok', present, `Present of ${staff.length}`, `<i class="meter"><i style="width:${pct}%"></i></i>`)}${kpi('clock', 'warn', late, `Late after ${S.graceMin} min grace`)}
      ${kpi('xcirc', 'bad', staff.length - present, 'Absent')}${kpi('clipboard', 'ink', pending, 'Work not written')}</div>
    <div class="tbl"><table><thead><tr><th>ID</th><th>Name</th><th>Shift</th><th>In</th><th>Out</th><th>Worked</th><th>OT</th><th>Daily work</th><th>Status</th><th></th></tr></thead><tbody>${trs}</tbody></table></div>`;
  $('#d').onchange = (e) => hrToday(e.target.value);
  H().querySelectorAll('[data-cal]').forEach(b => b.onclick = () => openCalendarFor(b.dataset.cal, date.slice(0, 7)));
  H().querySelectorAll('[data-photo]').forEach(b => b.onclick = () => showSelfies(b.dataset.photo, byEmpId(list, b.dataset.photo)));
  H().querySelectorAll('[data-edit]').forEach(b => b.onclick = () => editTimes(byEmpId(list, b.dataset.edit), () => hrToday(date)));
}
const byEmpId = (list, id) => list.find(r => r.id === id);

async function showSelfies(id, r) {
  const m = document.createElement('div'); m.className = 'modal'; m.innerHTML = `<div class="sheet wide-sheet"><p>Loading…</p></div>`;
  document.body.appendChild(m); m.onclick = (e) => { if (e.target === m) m.remove(); };
  const s = await store.getSelfies(id);
  const map = (lat, lng) => lat ? `<a href="https://www.google.com/maps?q=${lat},${lng}" target="_blank" rel="noopener">Map</a>` : '';
  $('.sheet', m).innerHTML = `<h2>${esc(r.name || r.empId)} · ${esc(r.date)}</h2><div class="selfies">
    <figure>${s.in ? `<img src="${s.in}" alt="Check-in selfie">` : '<div class="noimg">No photo</div>'}<figcaption>In ${hhmm(r.inAt)} · ${r.inDist ?? '—'} m ${map(r.inLat, r.inLng)}</figcaption></figure>
    <figure>${s.out ? `<img src="${s.out}" alt="Check-out selfie">` : '<div class="noimg">No photo</div>'}<figcaption>Out ${hhmm(r.outAt)} · ${r.outDist ?? '—'} m ${map(r.outLat, r.outLng)}</figcaption></figure></div>
    <button class="btn ghost" id="x">Close</button>`;
  $('#x', m).onclick = () => m.remove();
}

function editTimes(r, done) {
  const m = document.createElement('div'); m.className = 'modal';
  m.innerHTML = `<form class="sheet stack" id="ef"><h2>Correct times · ${esc(r.name || r.empId)} · ${esc(r.date)}</h2>
    <p class="note">Use only for genuine mistakes, such as a worker who forgot to check out. The change is recorded with your name.</p>
    <label>Shift<select id="es">${[1, 2, 3].map(n => `<option ${n === r.shift ? 'selected' : ''}>${n}</option>`).join('')}</select></label>
    <div class="row"><label class="grow">In<input type="time" id="ei" value="${hhmm(r.inAt)}" required></label><label class="grow">Out<input type="time" id="eo" value="${r.outAt ? hhmm(r.outAt) : ''}"></label></div>
    <label>Reason<input id="er" required placeholder="e.g. Forgot to check out, confirmed by supervisor"></label>
    <button class="btn">Save correction</button><button type="button" class="btn ghost" id="ec">Cancel</button></form>`;
  document.body.appendChild(m); $('#ec', m).onclick = () => m.remove();
  $('#ef', m).onsubmit = async (e) => {
    e.preventDefault();
    const mk = (v) => v ? new Date(`${r.date}T${v}:00+05:30`) : null;
    try {
      await store.editTimes(r.id, { shift: Number($('#es', m).value), inAt: mk($('#ei', m).value), outAt: mk($('#eo', m).value), editedBy: ME.name, editReason: $('#er', m).value, editedAt: new Date() });
      m.remove(); toast('Times corrected', 'ok'); done();
    } catch (err) { toast(err.message, 'bad'); }
  };
}

/* ---------- Calendar: one worker's month (daily work, P/OT, selfies), or all workers at a glance ---------- */
const CAL = { month: null, empId: null, mode: 'one' };
try { Object.assign(CAL, JSON.parse(sessionStorage.getItem('jayco-cal') || '{}')); } catch (e) {}
const saveCal = () => { try { sessionStorage.setItem('jayco-cal', JSON.stringify(CAL)); } catch (e) {} };
const MONTHS = {};   // month -> Promise of that month's attendance (all workers), reused while switching workers
const monthRecs = (month, fresh) => { if (fresh || !MONTHS[month]) MONTHS[month] = store.monthList(month).catch(e => { delete MONTHS[month]; throw e; }); return MONTHS[month]; };
const WD = ['Sun', 'Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat'];
const daysIn = (month) => { const [y, m] = month.split('-').map(Number); return new Date(Date.UTC(y, m, 0)).getUTCDate(); };
const dateOf = (month, d) => `${month}-${String(d).padStart(2, '0')}`;
const wdOf = (date) => new Date(date + 'T12:00:00Z').getUTCDay();
const monthName = (month) => new Date(month + '-15T12:00:00Z').toLocaleDateString('en-IN', { month: 'long', year: 'numeric', timeZone: 'UTC' });
const shiftMonth = (month, n) => { const [y, m] = month.split('-').map(Number); const d = new Date(Date.UTC(y, m - 1 + n, 1)); return d.toISOString().slice(0, 7); };
const fmtH = (min) => { const h = Math.floor(min / 60), m = min % 60; return !h ? `${m}m` : m ? `${h}h ${m}m` : `${h}h`; };
const fmtS = (min) => { const h = Math.floor(min / 60), m = min % 60; return !h ? `${m}m` : m ? `${h}:${String(m).padStart(2, '0')}` : `${h}h`; };

/* What one day means for one worker. */
function dayInfo(r, date) {
  const today = todayIST();
  if (!r) {
    if (date > today) return { k: 'future', code: '', label: '' };
    if (wdOf(date) === S.weeklyOff) return { k: 'off', code: 'WO', label: 'Weekly off' };
    if (date === today) return { k: 'wait', code: '', label: 'Not checked in yet' };
    return { k: 'abs', code: 'A', label: 'Absent' };
  }
  const d = RULES.dayResult(S, r.shift, minOfDayIST(r.inAt), r.outAt ? minOfDayIST(r.outAt) : null);
  if (!r.outAt) return date === today ? { k: 'duty', code: 'P', label: 'On duty', d } : { k: 'open', code: 'P?', label: 'No check-out', d };
  if (d.credit === 1) return { k: 'full', code: 'P', label: 'Full day', d };
  if (d.credit === 0.5) return { k: 'half', code: '½', label: 'Half day', d };
  return { k: 'short', code: 'S', label: 'Short day', d };
}
const workLines = (r) => {
  if (!r || !r.work || !r.work.op) return [];
  const w = r.work, out = [`${w.part ? w.part + ' · ' : ''}${w.op} · ${w.qty} pcs`];
  if (w.machine || w.notes) out.push([w.machine, w.notes].filter(Boolean).join(' · '));
  return out;
};
const workBadge = (r) => !r || !r.work || !r.work.op ? '' : r.workStatus === 'approved' ? `<span class="wb ok" title="Work approved">${ic('check', 'sm')}</span>` : r.workStatus === 'rejected' ? `<span class="wb bad" title="Work sent back">!</span>` : `<span class="wb warn" title="Work waiting for approval">•</span>`;

function openCalendarFor(empId, month) {
  Object.assign(CAL, { empId, month: month || CAL.month || monthIST(), mode: 'one' }); saveCal();
  TAB = 'calendar'; try { sessionStorage.setItem('jayco-tab', TAB); } catch (e) {}
  hrShell(); window.scrollTo(0, 0);
}

async function hrCalendar(fresh = true) {
  CAL.month = CAL.month || monthIST();
  const month = CAL.month;
  H().innerHTML = `${pageHead('Calendar', 'Daily attendance, work and selfies')}<div class="skel"></div>`;
  let recs, workers;
  try { [recs, workers] = await Promise.all([monthRecs(month, fresh), store.listWorkers()]); }
  catch (err) { H().innerHTML = `${pageHead('Calendar', 'Daily attendance, work and selfies')}<p class="err">${esc(err.message)}</p>`; return; }
  if (CAL.month !== month) return;   // the month changed while loading
  const staff = workers.filter(w => w.role !== 'admin' && !['pending', 'rejected', 'removed'].includes(w.status) && (w.active !== false || recs.some(r => r.empId === w.empId)))
    .sort((a, b) => String(a.name).localeCompare(String(b.name)));
  if (!staff.length) { H().innerHTML = `${pageHead('Calendar', 'Daily attendance, work and selfies')}<p class="muted">No workers yet.</p>`; return; }
  if (!staff.some(w => w.empId === CAL.empId)) CAL.empId = staff[0].empId;
  saveCal();
  const idx = staff.findIndex(w => w.empId === CAL.empId), w = staff[idx];
  const controls = `<div class="seg" role="group" aria-label="View"><button data-mode="one" aria-pressed="${CAL.mode === 'one'}">${ic('user', 'sm')} One worker</button><button data-mode="all" aria-pressed="${CAL.mode === 'all'}">${ic('grid', 'sm')} All workers</button></div>
    <div class="mnav"><button class="ibtn" id="mprev" title="Previous month" aria-label="Previous month">${ic('chevL')}</button><input type="month" id="m" value="${month}" max="${monthIST()}"><button class="ibtn" id="mnext" title="Next month" aria-label="Next month" ${month >= monthIST() ? 'disabled' : ''}>${ic('chevR')}</button></div>
    <button class="ibtn" id="print" title="Print" aria-label="Print">${ic('print')}</button>`;
  const byKey = {}; recs.forEach(r => { byKey[`${r.empId}_${r.date}`] = r; });
  const n = daysIn(month);

  if (CAL.mode === 'all') {
    const today = todayIST();
    const rows = staff.map(x => {
      let p = 0, a = 0, ot = 0;
      const cells = Array.from({ length: n }, (_, i) => {
        const date = dateOf(month, i + 1), r = byKey[`${x.empId}_${date}`], info = dayInfo(r, date);
        if (info.d) { p += info.d.credit; ot += info.d.otMin; } if (info.k === 'abs') a++;
        const otTxt = info.d && info.d.otMin ? `<small>+${fmtS(info.d.otMin)}</small>` : '';
        return `<td class="mc k-${info.k}${date === today ? ' is-today' : ''}"${r ? ` data-rid="${esc(r.id)}" tabindex="0" role="button"` : ''} title="${esc(x.name)} · ${date}${info.label ? ' · ' + info.label : ''}${info.d && info.d.otMin ? ' · OT ' + fmtH(info.d.otMin) : ''}">${info.code}${otTxt}</td>`;
      }).join('');
      return `<tr><th class="mname"><button class="who linkish" data-emp="${esc(x.empId)}">${avatarChip(x)}<span>${esc(x.name)}<small>${esc(x.empId)}</small></span></button></th>${cells}
        <td class="num tot">${p}</td><td class="num tot">${a}</td><td class="num tot">${ot ? fmtH(ot) : '—'}</td></tr>`;
    }).join('');
    H().innerHTML = `${pageHead(`${esc(monthName(month))}`, 'All workers · month at a glance', controls)}
      ${legend()}
      <div class="tbl muster"><table><thead><tr><th class="mname">Worker</th>${Array.from({ length: n }, (_, i) => { const date = dateOf(month, i + 1), wd = wdOf(date); return `<th class="mh${wd === S.weeklyOff ? ' off' : ''}${date === today ? ' is-today' : ''}"><b>${i + 1}</b>${WD[wd][0]}</th>`; }).join('')}
        <th>P</th><th>A</th><th>OT</th></tr></thead><tbody>${rows}</tbody></table></div>
      <p class="note">Click a name to open that worker's calendar, or a day to see the selfies and work.</p>`;
    H().querySelectorAll('[data-emp]').forEach(b => b.onclick = () => { CAL.empId = b.dataset.emp; CAL.mode = 'one'; saveCal(); hrCalendar(false); });
    H().querySelectorAll('[data-rid]').forEach(c => { const open = () => { const r = recs.find(x => x.id === c.dataset.rid); dayModal(staff.find(s => s.empId === r.empId) || { name: r.name, empId: r.empId }, r); }; c.onclick = open; c.onkeydown = (e) => { if (e.key === 'Enter' || e.key === ' ') { e.preventDefault(); open(); } }; });
  } else {
    let p = 0, late = 0, ot = 0, abs = 0, half = 0, wrote = 0;
    const cells = Array.from({ length: n }, (_, i) => {
      const date = dateOf(month, i + 1), r = byKey[`${w.empId}_${date}`], info = dayInfo(r, date), wd = wdOf(date);
      if (info.d) { p += info.d.credit; ot += info.d.otMin; if (info.d.isLate && r.outAt) late++; if (info.k === 'half') half++; }
      if (info.k === 'abs') abs++; if (r && r.work && r.work.op) wrote++;
      const lines = workLines(r);
      const inner = `<div class="cd-top"><b class="cd-n">${i + 1}</b><span class="cd-wd">${WD[wd]}</span>${info.d && info.d.isLate ? `<span class="cd-late" title="Late ${info.d.lateMin} min">+${info.d.lateMin}m</span>` : ''}${workBadge(r)}</div>
        ${lines.length ? `<ol class="cd-work">${lines.map(l => `<li>${esc(l)}</li>`).join('')}</ol>` : r ? '<div class="cd-empty">Work not written</div>' : info.k === 'off' ? '<div class="cd-empty">Weekly off</div>' : '<div class="cd-empty"></div>'}
        <div class="cd-foot">${r ? `<span class="cd-time">${hhmm(r.inAt)}–${r.outAt ? hhmm(r.outAt) : '…'}</span>` : '<span></span>'}<span class="cd-badges">${info.code ? `<span class="cd-st">${info.code}</span>` : ''}${info.d && info.d.otMin ? `<span class="cd-ot">+ OT ${fmtH(info.d.otMin)}</span>` : ''}</span></div>`;
      return r ? `<button class="cd k-${info.k}${date === todayIST() ? ' is-today' : ''}" data-rid="${esc(r.id)}" title="${esc(info.label)} · click for selfies">${inner}</button>`
        : `<div class="cd k-${info.k}${date === todayIST() ? ' is-today' : ''}">${inner}</div>`;
    });
    const lead = (wdOf(dateOf(month, 1)) + 6) % 7;   // weeks start on Monday
    const sh = S.shifts[w.shift] ? `Shift ${w.shift} · ${S.shifts[w.shift].start}–${S.shifts[w.shift].end}` : 'Shift not set';
    const stat = (v, l, tone = '') => `<div class="st ${tone}"><b>${v}</b><span>${l}</span></div>`;
    H().innerHTML = `${pageHead('Calendar', 'Daily attendance, work and selfies', controls)}
      <div class="wpick"><button class="ibtn" id="wprev" title="Previous worker" aria-label="Previous worker" ${idx <= 0 ? 'disabled' : ''}>${ic('chevL')}</button>
        <select id="wsel" aria-label="Worker">${staff.map(x => `<option value="${esc(x.empId)}" ${x.empId === w.empId ? 'selected' : ''}>${esc(x.name)} · ${esc(x.empId)}</option>`).join('')}</select>
        <button class="ibtn" id="wnext" title="Next worker" aria-label="Next worker" ${idx >= staff.length - 1 ? 'disabled' : ''}>${ic('chevR')}</button><span class="note">${idx + 1} of ${staff.length}</span></div>
      <section class="calcard">
        <header class="calhead"><div class="calhead-t"><div class="kicker">${esc(monthName(month))}</div><h2>${esc(monthName(month).split(' ')[0])} — ${esc(w.name)}</h2>
          <div class="calmeta">ID ${esc(w.empId)} · ${esc(sh)}${w.dept ? ' · ' + esc(w.dept) : ''}${w.role === 'supervisor' ? ' · Supervisor' : ''}</div>
          <div class="stats">${stat(p, 'Days present', 'ok')}${stat(abs, 'Absent', 'bad')}${stat(late, 'Late days', 'warn')}${stat(half, 'Half days')}${stat(ot ? fmtH(ot) : '0h', 'Overtime', 'red')}${stat(wrote, 'Work entries')}</div></div>
          <div class="calphoto" id="calphoto">${w.photo ? `<img src="${w.photo}" alt="${esc(w.name)}">` : `<span>${esc(initials(w.name))}</span>`}<small>Worker photo</small></div></header>
        ${legend()}
        <div class="calgrid">${['Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat', 'Sun'].map(d => `<div class="cal-wd">${d}</div>`).join('')}${'<div class="cd cd-pad" aria-hidden="true"></div>'.repeat(lead)}${cells.join('')}${'<div class="cd cd-pad" aria-hidden="true"></div>'.repeat((7 - (lead + n) % 7) % 7)}</div>
      </section>`;
    const go = (empId) => { CAL.empId = empId; saveCal(); hrCalendar(false); };
    $('#wsel').onchange = (e) => go(e.target.value);
    $('#wprev').onclick = () => idx > 0 && go(staff[idx - 1].empId);
    $('#wnext').onclick = () => idx < staff.length - 1 && go(staff[idx + 1].empId);
    H().querySelectorAll('[data-rid]').forEach(c => c.onclick = () => dayModal(w, recs.find(x => x.id === c.dataset.rid)));
    // No profile photo (HR-added workers): show their latest check-in selfie of the month instead.
    if (!w.photo) {
      const last = recs.filter(r => r.empId === w.empId && r.inAt).sort((a, b) => b.inAt - a.inAt)[0];
      if (last) store.getSelfies(last.id).then(s => { const el = $('#calphoto'); if (s.in && el && CAL.empId === w.empId) el.innerHTML = `<img src="${s.in}" alt="${esc(w.name)}"><small>Selfie ${esc(last.date.slice(8))} ${esc(monthName(month).split(' ')[0].slice(0, 3))}</small>`; }).catch(() => {});
    }
  }
  H().querySelectorAll('[data-mode]').forEach(b => b.onclick = () => { CAL.mode = b.dataset.mode; saveCal(); hrCalendar(false); });
  const setMonth = (m) => { if (!m || m > monthIST()) return; CAL.month = m; saveCal(); hrCalendar(false); };
  $('#m').onchange = (e) => setMonth(e.target.value);
  $('#mprev').onclick = () => setMonth(shiftMonth(month, -1));
  $('#mnext').onclick = () => setMonth(shiftMonth(month, 1));
  $('#print').onclick = () => window.print();
}
const legend = () => `<div class="legend"><span><i class="lg k-full">P</i>Full day</span><span><i class="lg k-half">½</i>Half day</span><span><i class="lg k-short">S</i>Short day</span><span><i class="lg k-open">P?</i>No check-out</span><span><i class="lg k-abs">A</i>Absent</span><span><i class="lg k-off">WO</i>Weekly off</span><span><i class="lg ot">OT</i>Overtime</span></div>`;

/* One day: both selfies, times, distance, work entry, with approve and edit. */
async function dayModal(w, r) {
  const info = dayInfo(r, r.date), d = info.d || {};
  const m = document.createElement('div'); m.className = 'modal';
  const map = (lat, lng) => lat ? `<a class="chipbtn" href="https://www.google.com/maps?q=${lat},${lng}" target="_blank" rel="noopener">${ic('map', 'sm')} Map</a>` : '';
  const work = r.work && r.work.op ? r.work : null;
  const render = (s) => `<div class="sheet wide-sheet daysheet">
    <div class="dayhead">${avatarChip(w)}<div><div class="kicker">${esc(longDate(r.date))}</div><h2>${esc(w.name || r.empId)}</h2></div><span class="cd-st big k-${info.k}">${info.code}</span><button class="ibtn" id="x" aria-label="Close">${ic('xcirc')}</button></div>
    <div class="daystats"><div><span>Shift</span><b>${r.shift}</b></div><div><span>In</span><b>${hhmm(r.inAt)}${d.isLate ? ` <em class="warn">+${d.lateMin}m</em>` : ''}</b></div><div><span>Out</span><b>${r.outAt ? hhmm(r.outAt) : '—'}</b></div>
      <div><span>Worked</span><b>${r.outAt ? RULES.fmtMin(d.workedMin) : '—'}</b></div><div><span>Overtime</span><b class="${d.otMin ? 'red' : ''}">${d.otMin ? fmtH(d.otMin) : '—'}</b></div><div><span>Status</span><b>${esc(info.label)}</b></div></div>
    <div class="selfies">
      <figure>${!s ? '<div class="noimg">Loading…</div>' : s.in ? `<img src="${s.in}" alt="Check-in selfie">` : '<div class="noimg">No photo</div>'}<figcaption><b>Check-in ${hhmm(r.inAt)}</b><span>${r.inDist ?? '—'} m from factory</span>${map(r.inLat, r.inLng)}</figcaption></figure>
      <figure>${!s ? '<div class="noimg">Loading…</div>' : s.out ? `<img src="${s.out}" alt="Check-out selfie">` : '<div class="noimg">No photo</div>'}<figcaption><b>Check-out ${hhmm(r.outAt)}</b><span>${r.outDist ?? '—'} m from factory</span>${map(r.outLat, r.outLng)}</figcaption></figure></div>
    <div class="daywork"><div class="row"><span class="kicker">Daily work</span>${work ? `<span class="pill ${r.workStatus === 'approved' ? 'ok' : r.workStatus === 'rejected' ? 'bad' : 'warn'}">${r.workStatus === 'approved' ? 'Approved' : r.workStatus === 'rejected' ? 'Sent back' : 'Waiting'}</span>` : ''}</div>
      ${work ? `<ol class="cd-work big"><li><b>${esc(work.part)}</b> · ${esc(work.op)} · ${esc(work.qty)} pcs</li>${work.machine ? `<li>Machine ${esc(work.machine)}</li>` : ''}${work.notes ? `<li>${esc(work.notes)}</li>` : ''}</ol>` : '<p class="muted">Work not written.</p>'}
      ${r.editedBy ? `<p class="note">Times corrected by ${esc(r.editedBy)}: ${esc(r.editReason || '')}</p>` : ''}</div>
    <div class="row wrap dayact">${work && r.workStatus !== 'approved' ? `<button class="btn small" data-act="approved">${ic('check', 'sm')} Approve work</button>` : ''}${work && r.workStatus !== 'rejected' ? `<button class="btn small ghost" data-act="rejected">Send back</button>` : ''}
      ${ME.role === 'admin' ? `<button class="btn small ghost" id="ed">${ic('edit', 'sm')} Edit times</button>` : ''}</div></div>`;
  m.innerHTML = render(null); document.body.appendChild(m);
  const close = () => { m.remove(); document.removeEventListener('keydown', esc_); };
  const esc_ = (e) => { if (e.key === 'Escape') close(); };
  document.addEventListener('keydown', esc_);
  const wire = () => {
    m.onclick = (e) => { if (e.target === m) close(); };
    $('#x', m).onclick = close;
    m.querySelectorAll('[data-act]').forEach(b => b.onclick = async () => {
      try { await store.setWorkStatus(r.id, b.dataset.act, ME.name); close(); toast(b.dataset.act === 'approved' ? 'Work approved' : 'Work sent back', 'ok'); hrCalendar(true); } catch (err) { toast(err.message, 'bad'); }
    });
    const ed = $('#ed', m); if (ed) ed.onclick = () => { close(); editTimes({ ...r, name: w.name }, () => hrCalendar(true)); };
  };
  wire();
  let s = {}; try { s = await store.getSelfies(r.id); } catch (e) {}
  if (!m.isConnected) return;
  m.innerHTML = render(s); wire();
}

/* ---------- Work records ---------- */
async function hrWork(date = todayIST(), filter = 'pending') {
  H().innerHTML = `${pageHead('Work records', 'Approve what each worker made today')}<div class="skel"></div>`;
  const list = (await store.dayList(date)).filter(r => r.work && r.work.op);
  const shown = list.filter(r => filter === 'all' || r.workStatus === filter).sort((a, b) => String(a.empId).localeCompare(b.empId));
  H().innerHTML = `${pageHead('Work records', esc(longDate(date)), `<input type="date" id="d" value="${date}">
    <select id="fl"><option value="pending">Waiting for approval</option><option value="approved">Approved</option><option value="rejected">Sent back</option><option value="all">All</option></select>`)}
    ${shown.length ? '' : '<p class="muted">Nothing here for this day.</p>'}
    <div class="cards">${shown.map(r => `<div class="card"><div class="row"><b>${esc(r.name || r.empId)}</b><span class="pill ${r.workStatus === 'approved' ? 'ok' : r.workStatus === 'rejected' ? 'bad' : 'warn'}">${r.workStatus === 'approved' ? 'Approved' : r.workStatus === 'rejected' ? 'Sent back' : 'Waiting'}</span></div>
      <div>${esc(r.work.part)} · <b>${esc(r.work.op)}</b> · ${esc(r.work.qty)} pcs${r.work.machine ? ' · ' + esc(r.work.machine) : ''}</div>
      ${r.work.notes ? `<div class="note">${esc(r.work.notes)}</div>` : ''}
      <div class="row"><button class="btn small" data-ok="${esc(r.id)}">Approve</button><button class="btn small ghost" data-no="${esc(r.id)}">Send back</button></div></div>`).join('')}</div>`;
  $('#fl').value = filter;
  $('#d').onchange = (e) => hrWork(e.target.value, filter);
  $('#fl').onchange = (e) => hrWork(date, e.target.value);
  const act = (id, st) => store.setWorkStatus(id, st, ME.name).then(() => hrWork(date, filter)).catch(e => toast(e.message, 'bad'));
  H().querySelectorAll('[data-ok]').forEach(b => b.onclick = () => act(b.dataset.ok, 'approved'));
  H().querySelectorAll('[data-no]').forEach(b => b.onclick = () => act(b.dataset.no, 'rejected'));
}

/* ---------- Payroll ---------- */
async function hrPayroll(month = monthIST()) {
  H().innerHTML = `${pageHead('Payroll', 'Wages, overtime, PF, ESI, advances and loans')}<div class="skel"></div>`;
  const [list, workers, adv, loans] = await Promise.all([store.monthList(month), store.listWorkers(), store.advances(month), store.loans()]);
  const staff = workers.filter(w => w.role !== 'admin');
  const [y, mo] = month.split('-').map(Number);
  const rows = staff.map(w => {
    const days = list.filter(r => r.empId === w.empId && r.outAt).map(r => RULES.dayResult(S, r.shift, minOfDayIST(r.inAt), minOfDayIST(r.outAt)));
    const a = adv.filter(x => x.empId === w.empId).reduce((s, x) => s + Number(x.amount || 0), 0);
    const ln = loans.filter(x => x.empId === w.empId).reduce((s, x) => s + RULES.loanForMonth(x, month).due, 0);
    return { w, p: RULES.monthPay(S, days, Number(w.dailyWage || 0), a, w.pfEsi !== false, ln) };
  }).filter(x => x.p.daysPresent > 0 || x.p.advance > 0 || x.p.loan > 0 || x.w.active !== false);
  const nameOf = (id) => (workers.find(w => w.empId === id) || {}).name || '';
  const tot = rows.reduce((s, { p }) => ({ gross: s.gross + p.gross, net: s.net + p.net, ot: s.ot + p.otPay, pf: s.pf + p.pf, esi: s.esi + p.esi }), { gross: 0, net: 0, ot: 0, pf: 0, esi: 0 });
  H().innerHTML = `${pageHead('Payroll', esc(monthName(month)), `<input type="month" id="m" value="${month}"><button class="btn small" id="csv">Download CSV</button>`)}
    <p class="note">${RULES.workingDays(y, mo - 1, S.weeklyOff)} working days, ${S.weeklyOff === 5 ? 'Friday' : 'Sunday'} off. Overtime: 1x under ${S.otThresholdH} h in the month, ${S.otRateHigh}x at ${S.otThresholdH} h or more. First ${S.lateFreeDays} late days free; each later late day costs 4 h, taken from overtime at 1x first.</p>
    <div class="kpis"><div class="kpi"><b>${inr(tot.gross)}</b><span>Gross</span></div><div class="kpi"><b>${inr(tot.ot)}</b><span>Overtime</span></div><div class="kpi"><b>${inr(tot.pf + tot.esi)}</b><span>PF + ESI</span></div><div class="kpi"><b>${inr(tot.net)}</b><span>Net to pay</span></div></div>
    <div class="tbl"><table><thead><tr><th>ID</th><th>Name</th><th>Wage/day</th><th>Days</th><th>Late</th><th>OT h</th><th>OT rate</th><th>Wages</th><th>OT pay</th><th>PF</th><th>ESI</th><th>Advance</th><th>Loan</th><th>Net</th></tr></thead>
    <tbody>${rows.map(({ w, p }) => `<tr><td>${esc(w.empId)}</td><td>${esc(w.name)}</td><td class="num">${inr(w.dailyWage)}</td><td class="num">${p.daysPresent}</td>
      <td class="num">${p.lateDays}${p.halfDays ? ` <span class="pill warn">${p.halfDays}×½</span>` : ''}</td><td class="num">${p.otH}${p.lateFromOtH ? ` <span class="note">(−${p.lateFromOtH})</span>` : ''}</td><td class="num">${p.mult}x</td>
      <td class="num">${inr(p.wages)}</td><td class="num">${inr(p.otPay)}</td><td class="num">${inr(p.pf)}</td><td class="num">${inr(p.esi)}</td><td class="num">${inr(p.advance)}</td><td class="num">${inr(p.loan)}</td><td class="num"><b>${inr(p.net)}</b></td></tr>`).join('')}</tbody></table></div>
    <h2>Salary advances, ${month}</h2>
    <form id="af" class="row wrap"><select id="ae">${staff.map(w => `<option value="${esc(w.empId)}">${esc(w.empId)} · ${esc(w.name)}</option>`).join('')}</select>
      <input id="aa" type="number" min="1" placeholder="Amount ₹" required><input id="an" placeholder="Note"><button class="btn small">Add advance</button></form>
    <ul class="list">${adv.map(a => `<li>${esc(a.empId)} · ${inr(a.amount)} ${a.note ? '· ' + esc(a.note) : ''} <button class="link" data-del="${esc(a.id)}">Remove</button></li>`).join('')}</ul>
    <h2>Loans</h2>
    <p class="note">The monthly instalment is cut from pay every month from the start month until the loan is repaid. Balances below are after ${month}'s instalment.</p>
    <form id="lf" class="row wrap"><select id="le">${staff.map(w => `<option value="${esc(w.empId)}">${esc(w.empId)} · ${esc(w.name)}</option>`).join('')}</select>
      <input id="la" type="number" min="1" placeholder="Loan amount ₹" required><input id="li" type="number" min="1" placeholder="Monthly instalment ₹" required>
      <label class="row">Start <input id="ls" type="month" value="${month}" required></label><input id="ln" placeholder="Note"><button class="btn small">Add loan</button></form>
    ${loans.length ? `<div class="tbl"><table><thead><tr><th>ID</th><th>Name</th><th>Loan</th><th>Instalment</th><th>Start</th><th>This month</th><th>Repaid</th><th>Balance</th><th>Months left</th><th></th></tr></thead><tbody>
      ${loans.sort((a, b) => String(a.empId).localeCompare(b.empId) || String(a.startMonth).localeCompare(b.startMonth)).map(l => { const r = RULES.loanForMonth(l, month); return `<tr>
        <td>${esc(l.empId)}</td><td>${esc(nameOf(l.empId))}${l.note ? ` <span class="note">${esc(l.note)}</span>` : ''}</td><td class="num">${inr(l.amount)}</td><td class="num">${inr(l.instalment)}</td><td>${esc(l.startMonth)}</td>
        <td class="num">${inr(r.due)}</td><td class="num">${inr(r.paidBefore + r.due)}</td><td class="num"><b>${inr(r.balance)}</b></td>
        <td class="num">${r.settled ? `<span class="pill">Settled ${esc(l.settledMonth)}</span>` : r.balance ? r.monthsLeft : '<span class="pill ok">Repaid</span>'}</td>
        <td>${!r.settled && r.balance ? `<button class="link" data-settle="${esc(l.id)}">Settle</button> ` : ''}<button class="link" data-ldel="${esc(l.id)}">Remove</button></td></tr>`; }).join('')}
    </tbody></table></div>` : '<p class="note">No loans yet.</p>'}`;
  $('#m').onchange = (e) => hrPayroll(e.target.value);
  $('#af').onsubmit = async (e) => { e.preventDefault(); await store.addAdvance({ empId: $('#ae').value, month, amount: Number($('#aa').value), note: $('#an').value, by: ME.name }); hrPayroll(month); };
  H().querySelectorAll('[data-del]').forEach(b => b.onclick = async () => { await store.deleteAdvance(b.dataset.del); hrPayroll(month); });
  $('#lf').onsubmit = async (e) => {
    e.preventDefault();
    const amount = Number($('#la').value), instalment = Number($('#li').value);
    if (instalment > amount) return toast('The instalment cannot be more than the loan.', 'bad');
    await store.addLoan({ empId: $('#le').value, amount, instalment, startMonth: $('#ls').value, note: $('#ln').value, by: ME.name });
    toast('Loan added', 'ok'); hrPayroll(month);
  };
  H().querySelectorAll('[data-settle]').forEach(b => b.onclick = async () => {
    const l = loans.find(x => x.id === b.dataset.settle);
    const owed = RULES.loanForMonth(l, month).paidBefore;
    if (!confirm(`Mark this loan as settled in ${month}? No more instalments will be cut from ${month} on. Repaid by instalments before ${month}: ${inr(owed)}; take the remaining ${inr(Number(l.amount) - owed)} in cash.`)) return;
    await store.settleLoan(l.id, month); hrPayroll(month);
  });
  H().querySelectorAll('[data-ldel]').forEach(b => b.onclick = async () => {
    if (!confirm('Remove this loan? Its instalments will disappear from every month\'s payroll.')) return;
    await store.deleteLoan(b.dataset.ldel); hrPayroll(month);
  });
  $('#csv').onclick = () => {
    const head = ['Emp ID', 'Name', 'Daily wage', 'Days present', 'Late days', 'Late half days', 'OT hours', 'OT hours used for late', 'OT rate', 'Wages', 'OT pay', 'Gross', 'PF', 'ESI', 'Advance', 'Loan instalment', 'Net'];
    const lines = rows.map(({ w, p }) => [w.empId, w.name, w.dailyWage, p.daysPresent, p.lateDays, p.halfDays, p.otH, p.lateFromOtH, p.mult, p.wages, p.otPay, p.gross, p.pf, p.esi, p.advance, p.loan, p.net]);
    const csv = [head, ...lines].map(r => r.map(v => `"${String(v ?? '').replace(/"/g, '""')}"`).join(',')).join('\n');
    const a = document.createElement('a'); a.href = URL.createObjectURL(new Blob(['﻿' + csv], { type: 'text/csv' })); a.download = `JAYCO-payroll-${month}.csv`; a.click();
  };
}

/* ---------- Workers ---------- */
async function hrWorkers() {
  const [allW, resets, seen] = await Promise.all([store.listWorkers(), store.pinResets().catch(() => []), store.appSeen().catch(() => ({}))]);
  const all = allW.filter(w => w.role !== 'admin').sort((a, b) => String(a.empId).localeCompare(b.empId));
  const ownerOf = (r) => all.find(w => w.status !== 'pending' && w.status !== 'rejected' && w.status !== 'removed' && (String(w.phone) === r.mobile || String(w.empId) === r.mobile));
  const pending = all.filter(w => w.status === 'pending');
  const removed = all.filter(w => w.status === 'removed');
  const workers = all.filter(w => w.status !== 'pending' && w.status !== 'rejected' && w.status !== 'removed');
  linkOldLogins(workers);
  const seenCell = (w) => { const d = seen[w.empId]; return d ? `<span class="pill ok" title="Last opened ${esc(d.toLocaleString('en-IN'))}">${esc(d.toLocaleDateString('en-IN', { day: 'numeric', month: 'short' }))}</span>` : '<span class="pill warn" title="This phone has not opened the app since reminders started">Not yet</span>'; };
  H().innerHTML = `${pageHead('Workers', `${workers.filter(w => w.active !== false).length} active employees`, '<button class="btn small" id="addbtn">+ Add employee</button>')}
    ${pending.length ? `<div class="card stack"><h2>New registrations waiting (${pending.length})</h2>
      <p class="note">Workers registered themselves in the app. Check the photo and details, set the Employee ID and daily wage, then approve. Their login stays their mobile number and PIN.</p>
      <div class="cards">${pending.map(w => `<form class="card stack" data-approve="${esc(w.uid)}"><div class="row" style="justify-content:flex-start">
        <div class="avatar">${w.photo ? `<img src="${w.photo}" alt="">` : ''}</div><div><b>${esc(w.name)}</b><div class="note">${esc(w.phone)}${w.dept ? ' · ' + esc(w.dept) : ''}</div></div></div>
        <div class="formgrid"><label>Employee ID<input name="empId" value="${esc(w.empId)}" required pattern="[A-Za-z0-9]+"></label>
        <label>Daily wage ₹<input name="wage" type="number" min="1" required></label>
        <label>Role<select name="role"><option value="worker">Worker</option><option value="supervisor">Supervisor</option></select></label>
        <label>Shift (worker chose)<select name="shift">${[1, 2, 3].map(n => `<option value="${n}" ${Number(w.shift || 1) === n ? 'selected' : ''}>Shift ${n} (${S.shifts[n].start}–${S.shifts[n].end})</option>`).join('')}</select></label></div>
        ${w.rulesAccepted ? '<div class="note">✓ Accepted company rules at registration</div>' : ''}
        <div class="row" style="justify-content:flex-start"><button class="btn small">Approve</button><button type="button" class="btn small ghost" data-reject="${esc(w.uid)}">Reject</button></div></form>`).join('')}</div></div>` : ''}
    ${resets.length ? `<div class="card stack"><h2>Forgot PIN requests (${resets.length})</h2>
      <p class="note">A worker asked for a new PIN. Compare the new selfie with their profile photo, call their mobile to confirm, then approve. Their attendance, pay and loans stay as they are.</p>
      <div class="cards">${resets.map(r => { const w = ownerOf(r); return `<div class="card stack"><div class="row" style="justify-content:flex-start">
        <div class="avatar">${r.photo ? `<img src="${r.photo}" alt="New selfie">` : ''}</div><div class="avatar">${w && w.photo ? `<img src="${w.photo}" alt="Profile photo">` : ''}</div>
        <div><b>${w ? esc(w.name) : 'No worker with this mobile'}</b><div class="note">${esc(r.mobile)}${w ? ' · ID ' + esc(w.empId) : ''}</div><div class="note">Left: new selfie · Right: profile</div></div></div>
        <div class="row" style="justify-content:flex-start">${w ? `<button class="btn small" data-rs-ok="${esc(r.uid)}">Approve new PIN</button>` : ''}<button class="btn small ghost" data-rs-no="${esc(r.uid)}">Reject</button></div></div>`; }).join('')}</div></div>` : ''}
    <form id="nf" class="card stack" hidden><h2>Add employee</h2>
      <p class="note">The worker signs in with their mobile number and the PIN you set here. They can change the PIN later in the app.</p><div class="formgrid">
      <label>Mobile number<input id="n-ph" inputmode="tel" required pattern="(\+?91)?0?[6-9][0-9]{9}" title="10-digit mobile number"></label><label>Name<input id="n-name" required></label>
      <label>Employee ID (optional)<input id="n-id" pattern="[A-Za-z0-9]+" title="Letters and numbers only" placeholder="Empty = mobile number"></label>
      <label>Department<input id="n-dept"></label>
      <label>Daily wage ₹<input id="n-wage" type="number" min="0" required></label>
      <label>Role<select id="n-role"><option value="worker">Worker</option><option value="supervisor">Supervisor (approves work)</option></select></label>
      <label>Shift<select id="n-shift">${[1, 2, 3].map(n => `<option value="${n}" ${Number(1) === n ? 'selected' : ''}>Shift ${n} (${S.shifts[n].start}–${S.shifts[n].end})</option>`).join('')}</select></label>
      <label>Starting PIN (6 digits)<input id="n-pin" inputmode="numeric" pattern="[0-9]{6}" required></label></div>
      <div class="row" style="justify-content:flex-start"><button class="btn small">Add employee</button><button type="button" class="btn small ghost" id="n-cancel">Cancel</button></div></form>
    <div class="tbl"><table><thead><tr><th>ID</th><th>Name</th><th>Dept</th><th>Mobile</th><th>Wage/day</th><th>Shift</th><th>Role</th><th>PF/ESI</th><th>Active</th><th>App</th><th></th></tr></thead><tbody>
    ${workers.map(w => `<tr data-uid="${esc(w.uid)}"><td>${esc(w.empId)}</td><td><input class="in" data-f="name" value="${esc(w.name)}"></td><td><input class="in" data-f="dept" value="${esc(w.dept)}"></td>
      <td><input class="in" data-f="phone" value="${esc(w.phone)}"></td><td><input class="in num" data-f="dailyWage" type="number" value="${esc(w.dailyWage)}"></td>
      <td><select class="in" data-f="shift">${[1, 2, 3].map(n => `<option value="${n}" ${Number(w.shift || 0) === n ? 'selected' : ''}>${n}</option>`).join('')}${w.shift ? '' : '<option value="" selected>—</option>'}</select></td>
      <td><select class="in" data-f="role"><option value="worker" ${w.role === 'worker' ? 'selected' : ''}>Worker</option><option value="supervisor" ${w.role === 'supervisor' ? 'selected' : ''}>Supervisor</option></select></td>
      <td><input type="checkbox" data-f="pfEsi" ${w.pfEsi !== false ? 'checked' : ''}></td><td><input type="checkbox" data-f="active" ${w.active !== false ? 'checked' : ''}></td>
      <td>${seenCell(w)}</td><td class="nowrap"><button class="link" data-save>Save</button> · <button class="link" data-pin>New PIN</button> · <button class="link" data-remove>Remove</button> · <button class="link" data-wcal>Calendar</button></td></tr>`).join('')}</tbody></table></div>
    <p class="note">Worker can't sign in? Tap <b>New PIN</b>, set a 6-digit PIN and tell them: sign in with your mobile number and this PIN. "App" shows the last day their phone opened the app.</p>
    ${removed.length ? `<details class="card stack"><summary><b>Removed employees (${removed.length})</b> <span class="note">Their attendance and pay history is kept.</span></summary>
      <div class="tbl"><table><thead><tr><th>ID</th><th>Name</th><th>Mobile</th><th>Removed by</th><th></th></tr></thead><tbody>
      ${removed.map(w => `<tr data-uid="${esc(w.uid)}"><td>${esc(w.empId)}</td><td>${esc(w.name)}</td><td>${esc(w.phone)}</td><td>${esc(w.removedBy || '')}</td>
        <td class="nowrap"><button class="link" data-restore>Restore</button> · <button class="link" data-delete>Delete forever</button></td></tr>`).join('')}</tbody></table></div></details>` : ''}`;
  const byUid = (el) => all.find(w => w.uid === el.closest('tr').dataset.uid);
  $('#addbtn').onclick = () => { $('#nf').hidden = false; $('#nf').scrollIntoView({ behavior: 'smooth' }); $('#n-ph').focus(); };
  $('#n-cancel').onclick = () => { $('#nf').hidden = true; };
  H().querySelectorAll('[data-pin]').forEach(b => b.onclick = () => newPinSheet(byUid(b)));
  H().querySelectorAll('[data-wcal]').forEach(b => b.onclick = () => openCalendarFor(byUid(b).empId));
  H().querySelectorAll('[data-remove]').forEach(b => b.onclick = async () => {
    const w = byUid(b);
    if (!confirm(`Remove ${w.name} (${w.empId})?\n\nThey can no longer sign in. Their attendance, pay and loan history stays, and you can restore them later from "Removed employees".`)) return;
    try { await store.removeWorker(w.uid, ME.name); toast(`${w.name} removed`, 'ok'); hrWorkers(); } catch (err) { toast(err.message, 'bad'); }
  });
  H().querySelectorAll('[data-restore]').forEach(b => b.onclick = async () => {
    const w = byUid(b);
    if (workers.some(x => String(x.empId).toLowerCase() === String(w.empId).toLowerCase())) return toast('Another active employee already uses this Employee ID.', 'bad');
    try { await store.restoreWorker(w.uid); toast(`${w.name} restored. They sign in with their old PIN.`, 'ok'); hrWorkers(); } catch (err) { toast(err.message, 'bad'); }
  });
  H().querySelectorAll('[data-delete]').forEach(b => b.onclick = async () => {
    const w = byUid(b);
    if (!confirm(`Delete ${w.name} (${w.empId}) forever?\n\nTheir profile is erased and cannot be restored. Past attendance records stay, but they will no longer appear in Payroll. Use this only for duplicates or wrong entries.`)) return;
    try { await store.deleteWorker(w.uid); toast(`${w.name} deleted`, 'ok'); hrWorkers(); } catch (err) { toast(err.message, 'bad'); }
  });
  H().querySelectorAll('[data-rs-ok]').forEach(b => b.onclick = async () => {
    const r = resets.find(x => x.uid === b.dataset.rsOk), w = ownerOf(r);
    if (!confirm(`Give ${w.name} (${r.mobile}) the new PIN they chose? Their old PIN stops working.`)) return;
    try { await store.approvePinReset(r, w); toast('Approved. The worker can sign in with the new PIN.', 'ok'); hrWorkers(); } catch (err) { toast(err.message, 'bad'); }
  });
  H().querySelectorAll('[data-rs-no]').forEach(b => b.onclick = async () => {
    if (!confirm('Reject this PIN request?')) return;
    try { await store.rejectPinReset(b.dataset.rsNo); toast('Request rejected', 'ok'); hrWorkers(); } catch (err) { toast(err.message, 'bad'); }
  });
  H().querySelectorAll('[data-approve]').forEach(f => f.onsubmit = async (e) => {
    e.preventDefault();
    const empId = f.empId.value.trim();
    if (all.some(x => x.uid !== f.dataset.approve && String(x.empId).toLowerCase() === empId.toLowerCase() && x.status !== 'rejected')) return toast('That Employee ID is already in use.', 'bad');
    const w = all.find(x => x.uid === f.dataset.approve);
    try {
      await store.saveWorker(f.dataset.approve, { empId, dailyWage: Number(f.wage.value), role: f.role.value, shift: Number(f.shift.value), active: true, status: 'approved', pfEsi: true, approvedBy: ME.name });
      if (w && w.phone && empId.toLowerCase() !== String(w.phone).toLowerCase()) await store.linkLogin(empId, empEmail(w.phone)).catch(() => {});
      toast('Approved. The worker can now sign in with their mobile number and PIN.', 'ok'); hrWorkers();
    }
    catch (err) { toast(err.message, 'bad'); }
  });
  H().querySelectorAll('[data-reject]').forEach(b => b.onclick = async () => {
    try { await store.saveWorker(b.dataset.reject, { status: 'rejected', active: false, approvedBy: ME.name }); toast('Registration rejected', 'ok'); hrWorkers(); } catch (err) { toast(err.message, 'bad'); }
  });
  $('#nf').onsubmit = async (e) => {
    e.preventDefault();
    const phone = normId($('#n-ph').value);
    const w = { empId: $('#n-id').value.trim() || phone, name: $('#n-name').value.trim(), dept: $('#n-dept').value.trim(), phone, dailyWage: Number($('#n-wage').value), role: $('#n-role').value, shift: Number($('#n-shift').value), pfEsi: true, addedBy: ME.name };
    const clash = all.find(x => x.status !== 'rejected' && (String(x.empId).toLowerCase() === w.empId.toLowerCase() || (x.phone && String(x.phone) === phone)));
    if (clash) return toast(clash.status === 'removed' ? `${clash.name} (${clash.empId}) is in Removed employees. Restore them instead.` : clash.status === 'pending' ? `${clash.name} already registered with this number. Approve them under "New registrations waiting".` : `${clash.name} (${clash.empId}) already uses this Employee ID or mobile number.`, 'bad');
    const b = e.submitter; if (b) b.disabled = true;
    try { await store.createWorker(w, $('#n-pin').value); toast(`${w.name} added. They sign in with mobile ${phone} and the PIN you set.`, 'ok'); hrWorkers(); }
    catch (err) { if (b) b.disabled = false; toast(err.code === 'auth/weak-password' ? 'PIN must be 6 digits.' : err.message, 'bad'); }
  };
  H().querySelectorAll('[data-save]').forEach(b => b.onclick = async () => {
    const tr = b.closest('tr'), data = {};
    tr.querySelectorAll('[data-f]').forEach(i => { data[i.dataset.f] = i.type === 'checkbox' ? i.checked : (i.dataset.f === 'dailyWage' || i.dataset.f === 'shift') ? Number(i.value) : i.value.trim(); });
    try { await store.saveWorker(tr.dataset.uid, data); toast('Saved', 'ok'); } catch (err) { toast(err.message, 'bad'); }
  });
}

/* HR sets a new PIN for a worker who cannot sign in. */
function newPinSheet(w) {
  const m = document.createElement('div'); m.className = 'modal';
  m.innerHTML = `<form class="sheet stack" id="pf"><h2>New PIN · ${esc(w.name)}</h2>
    <p class="note">Their old PIN stops working. Attendance, pay and loans stay as they are. Tell the worker to sign in with mobile <b>${esc(w.phone || w.empId)}</b> and this PIN.</p>
    <label>New 6-digit PIN<input id="pp" inputmode="numeric" pattern="[0-9]{6}" maxlength="6" required autocomplete="off"></label>
    <button class="btn" id="pgo">Set new PIN</button><button type="button" class="btn ghost" id="pc">Cancel</button></form>`;
  document.body.appendChild(m); $('#pc', m).onclick = () => m.remove(); $('#pp', m).focus();
  $('#pf', m).onsubmit = async (e) => {
    e.preventDefault(); $('#pgo', m).disabled = true;
    try { await store.setWorkerPin(w, $('#pp', m).value); m.remove(); toast(`New PIN set for ${w.name}.`, 'ok'); hrWorkers(); }
    catch (err) { $('#pgo', m).disabled = false; toast(err.message, 'bad'); }
  };
}

/* One-time fix for workers whose Employee ID and mobile differ: make both work at sign-in. */
let LINKED = false;
async function linkOldLogins(workers) {
  if (LINKED || store.mode !== 'firebase') return; LINKED = true;
  for (const w of workers) {
    const id = normId(w.empId), ph = normId(w.phone);
    if (!ph || !id || id === ph || w.pinResetAt) continue;
    const [other, own] = w.registeredAt ? [id, ph] : [ph, id];   // self-registered: login is the mobile; HR-added: login is the ID
    if (!(await store.getLogin(other))) await store.linkLogin(other, empEmail(own)).catch(() => {});
  }
}

/* ---------- Settings ---------- */
function hrSettings() {
  const f = S.factory;
  H().innerHTML = `${pageHead('Settings', 'Weekly off, factory location, shifts and rules')}<form id="sf" class="stack narrowish">
    <div class="card stack"><h2>Weekly off</h2><div class="switch" role="group" aria-label="Weekly off">
      <button type="button" data-off="0" aria-pressed="${S.weeklyOff === 0}">Sunday</button><button type="button" data-off="5" aria-pressed="${S.weeklyOff === 5}">Friday</button></div>
      <p class="note">Festival holidays are unpaid.</p></div>
    <div class="card stack"><h2>Factory location</h2><div class="formgrid">
      <label>Latitude<input id="s-lat" type="number" step="any" value="${f.lat}"></label><label>Longitude<input id="s-lng" type="number" step="any" value="${f.lng}"></label>
      <label>Radius (m)<input id="s-rad" type="number" min="10" value="${f.radius}"></label><label>Weakest GPS allowed (± m)<input id="s-acc" type="number" min="10" value="${S.maxAccuracy || 60}"></label></div>
      <a href="https://www.google.com/maps?q=${f.lat},${f.lng}" target="_blank" rel="noopener">Open pin in Google Maps</a></div>
    <div class="card stack"><h2>Late and overtime</h2><div class="formgrid">
      <label>Late grace (minutes)<input id="s-grace" type="number" min="0" value="${S.graceMin}"></label>
      <label>Free late days per month<input id="s-free" type="number" min="0" value="${S.lateFreeDays}"></label>
      <label>OT hours for higher rate<input id="s-ot" type="number" min="0" value="${S.otThresholdH}"></label>
      <label>Higher OT rate<input id="s-otr" type="number" step="0.25" min="1" value="${S.otRateHigh}"></label></div></div>
    <div class="card stack"><h2>Shift times</h2><div class="formgrid">${[1, 2, 3].map(n => `<label>Shift ${n} start<input type="time" id="s${n}a" value="${S.shifts[n].start}"></label><label>Shift ${n} end<input type="time" id="s${n}b" value="${S.shifts[n].end}"></label>`).join('')}</div>
      <p class="note">Lunch ${S.lunch.start}–${S.lunch.end} for every shift.</p></div>
    <button class="btn">Save settings</button></form>
    ${store.mode === 'firebase' ? `<div class="card stack"><h2>Selfie storage</h2><p class="note">Selfies older than ${S.selfieKeepDays} days can be deleted to stay inside the free plan. Attendance records are kept.</p><button class="btn ghost small" id="purge">Delete old selfies</button></div>` : ''}`;
  let off = S.weeklyOff;
  H().querySelectorAll('[data-off]').forEach(b => b.onclick = () => { off = +b.dataset.off; H().querySelectorAll('[data-off]').forEach(x => x.setAttribute('aria-pressed', +x.dataset.off === off)); });
  $('#sf').onsubmit = async (e) => {
    e.preventDefault(); const v = (id) => Number($(id).value);
    const next = { weeklyOff: off, factory: { lat: v('#s-lat'), lng: v('#s-lng'), radius: v('#s-rad') }, maxAccuracy: v('#s-acc'), graceMin: v('#s-grace'), lateFreeDays: v('#s-free'), otThresholdH: v('#s-ot'), otRateHigh: v('#s-otr'),
      shifts: Object.fromEntries([1, 2, 3].map(n => [n, { start: $(`#s${n}a`).value, end: $(`#s${n}b`).value }])) };
    try { await store.saveSettings(next); S = { ...S, ...next }; toast('Settings saved', 'ok'); } catch (err) { toast(err.message, 'bad'); }
  };
  const p = $('#purge'); if (p) p.onclick = async () => {
    const cut = new Date(Date.now() - S.selfieKeepDays * 864e5).toISOString().slice(0, 10);
    try { const n = await store.purgeSelfies(cut); toast(`${n} old selfie records deleted`, 'ok'); } catch (err) { toast(err.message, 'bad'); }
  };
}
