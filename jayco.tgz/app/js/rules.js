/* JAYCO attendance and salary rules. Pure functions, no browser APIs.
   Used by the app and by tests (node). All times are minutes since midnight, IST. */
(function (root) {
  const DEFAULTS = {
    factory: { lat: 22.991259, lng: 72.8416972, radius: 50 },
    shifts: {
      1: { start: '08:00', end: '16:30' },
      2: { start: '08:30', end: '17:00' },
      3: { start: '09:30', end: '18:00' }
    },
    lunch: { start: '12:00', end: '12:30' },
    weeklyOff: 0,            // 0 = Sunday, 5 = Friday (HR switch)
    graceMin: 5,             // late only if more than 5 minutes after shift start
    lateFreeDays: 7,         // first 7 late days in a month are free
    otThresholdH: 60,        // monthly OT hours at which 1.5x applies
    otRateHigh: 1.5,
    otRoundMin: 15,          // OT counted in full 15-minute blocks
    fullDayMin: 450,         // 7 h 30 m worked = full day
    halfDayMin: 240,         // 4 h worked = half day
    shiftWorkMin: 480,       // 8 working hours per shift
    pfRate: 0.12, pfWageCap: 15000,
    esiRate: 0.0075, esiGrossLimit: 21000,
    selfieKeepDays: 180
  };

  const toMin = (hhmm) => { const [h, m] = hhmm.split(':').map(Number); return h * 60 + m; };
  const fmtMin = (m) => { m = Math.max(0, Math.round(m)); return `${Math.floor(m / 60)}h ${String(m % 60).padStart(2, '0')}m`; };

  function distanceM(lat1, lng1, lat2, lng2) {
    const R = 6371000, r = Math.PI / 180;
    const dLat = (lat2 - lat1) * r, dLng = (lng2 - lng1) * r;
    const a = Math.sin(dLat / 2) ** 2 + Math.cos(lat1 * r) * Math.cos(lat2 * r) * Math.sin(dLng / 2) ** 2;
    return 2 * R * Math.asin(Math.sqrt(a));
  }

  /* One day. inMin/outMin = minutes since midnight. Returns worked, late, OT, day credit. */
  function dayResult(s, shiftNo, inMin, outMin) {
    const sh = s.shifts[shiftNo];
    const start = toMin(sh.start), end = toMin(sh.end);
    const ls = toMin(s.lunch.start), le = toMin(s.lunch.end);
    const lateMin = Math.max(0, inMin - start);
    const isLate = lateMin > s.graceMin;
    const from = Math.max(inMin, start);           // early arrival is not paid
    const to = outMin == null ? null : outMin;
    if (to == null) return { lateMin, isLate, workedMin: 0, otMin: 0, credit: 0, open: true };
    const lunchOverlap = Math.max(0, Math.min(to, le) - Math.max(from, ls));
    const workedMin = Math.max(0, to - from - lunchOverlap);
    const rawOt = Math.max(0, to - Math.max(end, inMin));   // only time actually worked past shift end
    const otMin = Math.floor(rawOt / s.otRoundMin) * s.otRoundMin;
    const shiftMin = workedMin - Math.min(rawOt, workedMin);
    const credit = shiftMin >= s.fullDayMin ? 1 : shiftMin >= s.halfDayMin ? 0.5 : 0;
    return { lateMin, isLate, workedMin, otMin, credit, open: false };
  }

  /* One worker, one month.
     days: [{credit, isLate, otMin}], wage: daily wage, advance: rupees. */
  function monthPay(s, days, wage, advance = 0, applyStat = true, loan = 0) {
    const hourly = wage / (s.shiftWorkMin / 60);
    const daysPresent = days.reduce((a, d) => a + d.credit, 0);
    const lateDays = days.filter(d => d.isLate && d.credit > 0).length;
    const otH = days.reduce((a, d) => a + d.otMin, 0) / 60;
    const mult = otH >= s.otThresholdH ? s.otRateHigh : 1;   // band uses the month's full OT hours
    const halfDays = Math.max(0, lateDays - s.lateFreeDays);
    const lateH = halfDays * (s.shiftWorkMin / 60) / 2;      // each extra late day costs half a day
    const lateFromOtH = Math.min(otH, lateH);                // recovered from OT at single rate first
    const lateCut = (lateH - lateFromOtH) * hourly;          // rest cut from wages
    const wages = wage * daysPresent - lateCut;
    const otPaidH = otH - lateFromOtH;
    const otPay = otPaidH * hourly * mult;
    const gross = wages + otPay;
    const pf = applyStat ? Math.round(Math.min(Math.max(wages, 0), s.pfWageCap) * s.pfRate) : 0;
    const esi = applyStat && gross <= s.esiGrossLimit ? Math.ceil(gross * s.esiRate) : 0;
    const net = gross - pf - esi - advance - loan;
    const r2 = (n) => Math.round(n * 100) / 100;
    return {
      hourly: r2(hourly), daysPresent, lateDays, halfDays, otH: r2(otH), mult,
      lateFromOtH: r2(lateFromOtH), otPaidH: r2(otPaidH), lateCut: Math.round(lateCut),
      wages: Math.round(wages), otPay: Math.round(otPay), gross: Math.round(gross),
      pf, esi, advance, loan, net: Math.round(net)
    };
  }

  /* Loan with a fixed monthly instalment, cut from pay from startMonth on.
     loan: {amount, instalment, startMonth 'YYYY-MM', settledMonth?}. month: 'YYYY-MM'.
     Returns this month's cut, what was repaid before it, and the balance left after it. */
  function loanForMonth(loan, month) {
    const idx = (m) => { const [y, mo] = String(m).split('-').map(Number); return y * 12 + mo - 1; };
    const amount = Math.max(0, Number(loan.amount || 0)), inst = Math.max(0, Number(loan.instalment || 0));
    const k = idx(month) - idx(loan.startMonth);
    if (loan.settledMonth && idx(month) >= idx(loan.settledMonth)) {
      const paidBefore = Math.min(amount, Math.max(0, idx(loan.settledMonth) - idx(loan.startMonth)) * inst);
      return { due: 0, paidBefore, balance: 0, monthsLeft: 0, settled: true };
    }
    if (k < 0 || !inst) return { due: 0, paidBefore: 0, balance: amount, monthsLeft: inst ? Math.ceil(amount / inst) : 0, settled: false };
    const paidBefore = Math.min(amount, k * inst);
    const due = Math.min(inst, amount - paidBefore);
    const balance = amount - paidBefore - due;
    return { due, paidBefore, balance, monthsLeft: Math.ceil(balance / inst), settled: false };
  }

  function workingDays(year, month0, weeklyOff) {
    let n = 0; const last = new Date(year, month0 + 1, 0).getDate();
    for (let d = 1; d <= last; d++) if (new Date(year, month0, d).getDay() !== weeklyOff) n++;
    return n;
  }

  const api = { DEFAULTS, toMin, fmtMin, distanceM, dayResult, monthPay, loanForMonth, workingDays };
  if (typeof module !== 'undefined' && module.exports) module.exports = api; else root.RULES = api;
})(typeof self !== 'undefined' ? self : this);
